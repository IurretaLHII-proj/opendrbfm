-- MySQL dump 10.13  Distrib 5.5.60, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: ma_drbfm
-- ------------------------------------------------------
-- Server version	5.5.60-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action`
--

DROP TABLE IF EXISTS `action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) NOT NULL COMMENT 'source',
  `name` varchar(255) NOT NULL,
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action`
--

LOCK TABLES `action` WRITE;
/*!40000 ALTER TABLE `action` DISABLE KEYS */;
INSERT INTO `action` VALUES (1,1,164,'create','a:0:{}','2019-01-24 08:44:51','op'),(2,13,165,'create','a:0:{}','2019-01-28 10:49:10','op'),(3,13,166,'create','a:0:{}','2019-01-28 11:04:03','op'),(4,13,166,'create','a:0:{}','2019-02-11 10:50:32','op'),(5,13,167,'create','a:0:{}','2019-02-11 10:50:50','op'),(6,1,168,'create','a:0:{}','2019-03-08 12:56:43','op'),(7,1,131,'update','a:1:{s:6:\"insert\";a:2:{i:0;a:8:{s:2:\"id\";i:97;s:4:\"name\";s:15:\"Severa (50-70%)\";s:8:\"longName\";s:41:\"Extrusión Hacia Delante. Severa (50-70%)\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";s:248:\"<ul><li>No cilíndricas. (estrias, ranuras, cuadrados etc)</li><li>Con ángulo en vez de radio</li><li>Grandes longitudes de extrusión (L&gt;3d??)</li><li>Con estacion previa de preparación</li><li>Distribuida entre buterola/matriz<br/></li></ul>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:54:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:54:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:8:{s:2:\"id\";i:168;s:4:\"name\";s:7:\"Directa\";s:8:\"longName\";s:33:\"Extrusión Hacia Delante. Directa\";s:5:\"owner\";r:7;s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-08 13:56:43\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-08 13:56:43\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-08 12:56:51','op'),(8,1,95,'update','a:0:{}','2019-03-08 14:33:45','op'),(9,1,108,'update','a:1:{s:6:\"insert\";a:2:{i:0;a:8:{s:2:\"id\";i:95;s:4:\"name\";s:9:\"Standard!\";s:8:\"longName\";s:16:\"Corte. Standard!\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:51:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:51:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:8:{s:2:\"id\";i:108;s:4:\"name\";s:33:\"Standard! + Grandes deformaciones\";s:8:\"longName\";s:40:\"Corte. Standard! + Grandes deformaciones\";s:5:\"owner\";r:7;s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:2:{i:0;O:19:\"MA\\Entity\\Operation\":11:{s:5:\"\0*\0id\";i:95;s:7:\"\0*\0name\";s:9:\"Standard!\";s:14:\"\0*\0description\";N;s:7:\"\0*\0type\";O:54:\"DoctrineORMModule\\Proxy\\__CG__\\MA\\Entity\\OperationType\":8:{s:17:\"__isInitialized__\";b:1;s:5:\"\0*\0id\";i:8;s:7:\"\0*\0text\";s:5:\"Corte\";s:14:\"\0*\0description\";s:159:\"<p>Corte transversal del alambre ya enderezado a la longitud deseada, es importante el acabado de la zona deformada para evitar problemas posteriores.<br/></p>\";s:7:\"\0*\0user\";r:7;s:13:\"\0*\0operations\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:50:37\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:50:37\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}s:7:\"\0*\0user\";r:7;s:9:\"\0*\0stages\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:11:\"\0*\0children\";r:27;s:10:\"\0*\0parents\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:1:{i:0;O:19:\"MA\\Entity\\Operation\":11:{s:5:\"\0*\0id\";i:108;s:7:\"\0*\0name\";s:33:\"Standard! + Grandes deformaciones\";s:14:\"\0*\0description\";N;s:7:\"\0*\0type\";r:67;s:7:\"\0*\0user\";r:7;s:9:\"\0*\0stages\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:11:\"\0*\0children\";r:60;s:10:\"\0*\0parents\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:1:{i:0;r:94;}}s:14:\"\0*\0initialized\";b:0;}s:8:\"\0*\0hints\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:03:41\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:03:41\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}s:14:\"\0*\0initialized\";b:0;}s:8:\"\0*\0hints\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:10:\"\0*\0created\";r:48;s:10:\"\0*\0updated\";r:44;}i:1;r:94;}}s:14:\"\0*\0initialized\";b:1;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";r:118;s:7:\"created\";r:114;}}}','2019-03-08 14:37:01','op'),(10,1,108,'update','a:0:{}','2019-03-08 14:37:26','op'),(11,1,95,'update','a:0:{}','2019-03-08 14:37:30','op'),(12,1,169,'create','a:0:{}','2019-03-12 19:59:50','op'),(13,1,170,'create','a:0:{}','2019-03-21 21:15:43','op'),(14,1,96,'update','a:1:{s:6:\"insert\";a:2:{i:0;a:8:{s:2:\"id\";i:109;s:4:\"name\";s:10:\"Escuadrado\";s:8:\"longName\";s:25:\"Preparación . Escuadrado\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:04:02\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:04:02\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:8:{s:2:\"id\";i:96;s:4:\"name\";s:21:\"Escuadrado + En radio\";s:8:\"longName\";s:36:\"Preparación . Escuadrado + En radio\";s:5:\"owner\";r:7;s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:2:{i:0;O:19:\"MA\\Entity\\Operation\":11:{s:5:\"\0*\0id\";i:109;s:7:\"\0*\0name\";s:10:\"Escuadrado\";s:14:\"\0*\0description\";N;s:7:\"\0*\0type\";O:54:\"DoctrineORMModule\\Proxy\\__CG__\\MA\\Entity\\OperationType\":8:{s:17:\"__isInitialized__\";b:1;s:5:\"\0*\0id\";i:9;s:7:\"\0*\0text\";s:12:\"Preparación\";s:14:\"\0*\0description\";N;s:7:\"\0*\0user\";r:7;s:13:\"\0*\0operations\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:53:47\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:53:47\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}s:7:\"\0*\0user\";r:7;s:9:\"\0*\0stages\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:11:\"\0*\0children\";r:27;s:10:\"\0*\0parents\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:1:{i:0;O:19:\"MA\\Entity\\Operation\":11:{s:5:\"\0*\0id\";i:96;s:7:\"\0*\0name\";s:21:\"Escuadrado + En radio\";s:14:\"\0*\0description\";N;s:7:\"\0*\0type\";r:67;s:7:\"\0*\0user\";r:7;s:9:\"\0*\0stages\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:11:\"\0*\0children\";r:60;s:10:\"\0*\0parents\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:1:{i:0;r:94;}}s:14:\"\0*\0initialized\";b:0;}s:8:\"\0*\0hints\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:53:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:53:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}s:14:\"\0*\0initialized\";b:0;}s:8:\"\0*\0hints\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:10:\"\0*\0created\";r:48;s:10:\"\0*\0updated\";r:44;}i:1;r:94;}}s:14:\"\0*\0initialized\";b:1;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";r:118;s:7:\"created\";r:114;}}}','2019-03-22 17:59:28','op'),(15,1,96,'update','a:0:{}','2019-03-22 17:59:42','op'),(16,1,96,'update','a:0:{}','2019-03-22 17:59:49','op'),(17,1,96,'update','a:0:{}','2019-03-22 17:59:59','op'),(18,1,166,'update','a:0:{}','2019-03-22 20:53:54','op'),(19,1,167,'update','a:0:{}','2019-03-22 20:54:06','op'),(20,1,170,'create','a:0:{}','2019-03-22 21:04:02','op'),(21,1,171,'create','a:0:{}','2019-03-22 21:05:14','op'),(22,1,172,'create','a:0:{}','2019-03-22 21:05:39','op'),(23,1,173,'create','a:0:{}','2019-03-22 21:06:28','op'),(24,1,174,'create','a:0:{}','2019-03-22 21:06:52','op'),(25,1,175,'create','a:0:{}','2019-03-22 21:07:29','op'),(26,1,176,'create','a:1:{s:6:\"insert\";a:2:{i:0;a:8:{s:2:\"id\";i:172;s:4:\"name\";s:7:\"De paso\";s:8:\"longName\";s:16:\"Frogak . De paso\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-22 22:05:39\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-22 22:05:39\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:8:{s:2:\"id\";i:173;s:4:\"name\";s:18:\"Estándar (30-50%)\";s:8:\"longName\";s:27:\"Frogak . Estándar (30-50%)\";s:5:\"owner\";r:7;s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-22 22:06:28\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-22 22:06:28\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-28 15:49:38','op'),(27,1,177,'create','a:0:{}','2019-03-28 15:56:01','op'),(28,1,178,'create','a:0:{}','2019-03-28 15:56:12','op'),(29,1,179,'create','a:1:{s:6:\"insert\";a:2:{i:0;a:8:{s:2:\"id\";i:177;s:4:\"name\";s:16:\"Operation type 1\";s:8:\"longName\";s:25:\"Frogak . Operation type 1\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-28 16:56:01\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-28 16:56:01\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:8:{s:2:\"id\";i:178;s:4:\"name\";s:16:\"Operation type 2\";s:8:\"longName\";s:25:\"Frogak . Operation type 2\";s:5:\"owner\";r:7;s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-28 16:56:12\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-28 16:56:12\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-28 15:56:19','op'),(30,1,180,'create','a:0:{}','2019-03-28 15:56:43','op'),(31,1,181,'create','a:0:{}','2019-03-28 15:56:54','op'),(32,1,182,'create','a:0:{}','2019-03-28 19:56:28','op'),(33,1,182,'update','a:0:{}','2019-03-28 19:56:38','op'),(34,1,182,'update','a:0:{}','2019-03-28 19:56:45','op'),(35,1,183,'create','a:0:{}','2019-03-28 19:57:12','op');
/*!40000 ALTER TABLE `action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) NOT NULL COMMENT 'source',
  `prt_id` int(11) DEFAULT NULL COMMENT 'parent',
  `body` text NOT NULL,
  `cmm_c` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent` (`prt_id`),
  KEY `source` (`src_id`),
  KEY `user` (`uid`),
  CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`prt_id`) REFERENCES `comment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (32,1,25,NULL,'<p>ddd</p>',0,'2019-03-25 21:03:47','influence'),(33,1,25,NULL,'<p>dscdc</p>',1,'2019-03-25 21:03:50','influence'),(34,1,25,33,'<p>dcscd</p>',0,'2019-03-25 21:03:52','influence');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `phone` varchar(64) NOT NULL,
  `contact` varchar(64) NOT NULL,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `descr` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (4,1111,'Customer 1','customer1@example.eus','123456','Customer1 Name',1,'2019-01-21 19:02:16','2019-01-21 19:02:16','<p>Customer1 Description</p>');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int(6) NOT NULL,
  `descr` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `source` (`src_id`),
  KEY `user` (`uid`),
  CONSTRAINT `image_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `image_ibfk_2` FOREIGN KEY (`src_id`) REFERENCES `process_stage` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
INSERT INTO `image` VALUES (62,1,89,'./public/img/phpsUjWey','image/png',13471,NULL,'2019-01-21 18:07:18'),(63,1,90,'./public/img/phpzWSrtJ','image/png',4872,NULL,'2019-01-21 18:07:41'),(64,1,91,'./public/img/phpyWXhgR','image/png',41576,NULL,'2019-01-21 18:08:04'),(65,1,92,'./public/img/phpHbL5oU','image/png',53089,NULL,'2019-01-21 18:08:25'),(66,1,93,'./public/img/phpodQWH3','image/png',50115,NULL,'2019-01-21 18:08:45'),(67,1,94,'./public/img/phpEiOj7q','image/png',19389,NULL,'2019-01-21 18:08:56'),(89,16,117,'./public/img/php7a7ajr','image/png',2687,NULL,'2019-01-25 09:38:25'),(92,16,122,'./public/img/phpzlCOj8','image/png',4868,NULL,'2019-01-25 09:48:41'),(93,16,123,'./public/img/php681kTn','image/png',4305,'Texto de la Imagen','2019-01-25 09:52:00'),(94,16,127,'./public/img/php681kTn','image/png',4305,'Texto de la Imagen','2019-01-25 09:54:26'),(95,16,126,'./public/img/phpzlCOj8','image/png',4868,NULL,'2019-01-25 09:54:26'),(96,16,125,'./public/img/php7a7ajr','image/png',2687,NULL,'2019-01-25 09:54:26'),(98,13,NULL,'./public/img/phpHJClSL','image/png',7932,NULL,'2019-01-28 09:47:38'),(102,13,133,'./public/img/phpCRL1EC','image/png',9137,NULL,'2019-01-28 10:27:21'),(103,13,134,'./public/img/phpW5QAVq','image/png',7932,NULL,'2019-01-28 10:38:18'),(104,13,135,'./public/img/phpbLLOg6','image/png',16035,NULL,'2019-01-28 11:09:56'),(105,13,136,'./public/img/phpW5XPuc','image/png',24092,NULL,'2019-01-28 11:20:59'),(106,13,137,'./public/img/phps0RlBL','image/png',46200,NULL,'2019-01-29 10:00:27'),(118,13,153,'./public/img/phps0RlBL','image/png',46200,NULL,'2019-01-30 11:39:27'),(119,13,152,'./public/img/phpW5XPuc','image/png',24092,NULL,'2019-01-30 11:39:27'),(120,13,151,'./public/img/phpbLLOg6','image/png',16035,NULL,'2019-01-30 11:39:27'),(121,13,150,'./public/img/phpW5QAVq','image/png',7932,NULL,'2019-01-30 11:39:27'),(122,13,149,'./public/img/phpCRL1EC','image/png',9137,NULL,'2019-01-30 11:39:27'),(128,13,159,'./public/img/phpzxixIT','image/png',45667,NULL,'2019-01-30 11:45:48'),(129,13,160,'./public/img/phpmiSS5N','image/png',2948,NULL,'2019-02-08 12:08:46'),(130,13,161,'./public/img/phpJwM5Xj','image/png',5757,NULL,'2019-02-08 12:14:38'),(131,13,162,'./public/img/phpPN9qjn','image/png',6635,NULL,'2019-02-08 12:18:58'),(132,13,163,'./public/img/php6qg3iV','image/png',21426,NULL,'2019-02-11 09:54:55'),(133,13,164,'./public/img/php6WjqMW','image/png',18943,NULL,'2019-02-11 10:24:19'),(134,13,165,'./public/img/phpY4Ldm8','image/png',18943,NULL,'2019-02-11 10:31:04'),(135,13,166,'./public/img/phpvrAMQ9','image/png',15509,NULL,'2019-02-12 07:07:30'),(136,13,173,'./public/img/phpvrAMQ9','image/png',15509,NULL,'2019-02-12 07:09:29'),(137,13,172,'./public/img/phpY4Ldm8','image/png',18943,NULL,'2019-02-12 07:09:29'),(138,13,171,'./public/img/php6WjqMW','image/png',18943,NULL,'2019-02-12 07:09:29'),(139,13,170,'./public/img/php6qg3iV','image/png',21426,NULL,'2019-02-12 07:09:29'),(140,13,169,'./public/img/phpPN9qjn','image/png',6635,NULL,'2019-02-12 07:09:29'),(141,13,168,'./public/img/phpJwM5Xj','image/png',5757,NULL,'2019-02-12 07:09:29'),(142,13,167,'./public/img/phpmiSS5N','image/png',2948,NULL,'2019-02-12 07:09:29'),(146,16,178,'./public/img/phpUpujmH','image/jpeg',27688,NULL,'2019-03-09 05:47:39'),(147,16,179,'./public/img/phpBOLFYK','image/jpeg',27688,NULL,'2019-03-09 05:50:21');
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `src_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `cmm_c` int(4) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(24) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `source` (`src_id`),
  KEY `user` (`uid`),
  CONSTRAINT `note_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note`
--

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;
INSERT INTO `note` VALUES (12,'<p>Razón 1.1<br/></p>',7,1,0,'2019-03-28 20:35:04','hint-reason'),(13,'<p>Influencia 1.1.1<br/></p>',5,1,0,'2019-03-28 20:35:12','hint-influence'),(14,'<p>Influencia 1.1.2<br/></p>',6,1,0,'2019-03-28 20:35:25','hint-influence'),(15,'<p>Razón 1.2<br/></p>',8,1,0,'2019-03-28 20:35:48','hint-reason'),(16,'<p>Simulación 1.1.1.1<br/></p>',5,1,0,'2019-03-28 20:36:27','hint-suggestion'),(17,'<p>Simulación 1.1.1.2<br/></p>',6,1,0,'2019-03-28 20:36:38','hint-suggestion'),(18,'<p>Simulación 1.1.2.1<br/></p>',7,1,0,'2019-03-28 20:36:54','hint-suggestion'),(19,'<p>Influencia 1.2<span id=\"selectionBoundary_1553805506136_6449557363999253\" class=\"rangySelectionBoundary\">&#65279;</span>.1.1<br/></p>',7,1,0,'2019-03-28 20:37:21','hint-influence'),(20,'<p>Effect 1.1.1.2.1<br/></p>',6,1,0,'2019-03-28 20:39:51','hint-effect'),(22,'<p>Prevention 1.1.1.2.1<br/></p>',6,1,0,'2019-03-28 20:40:25','hint-prevention');
/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process`
--

DROP TABLE IF EXISTS `process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `number` int(4) NOT NULL,
  `line` int(2) NOT NULL,
  `code` int(11) NOT NULL,
  `plant` varchar(64) NOT NULL,
  `machine` varchar(64) NOT NULL,
  `p_num` varchar(64) NOT NULL COMMENT 'piece number',
  `p_name` varchar(64) NOT NULL COMMENT 'piece name',
  `complex` varchar(4) NOT NULL DEFAULT 'AA',
  `ctm_id` int(11) NOT NULL COMMENT 'customer',
  `body` text,
  `uid` int(11) NOT NULL COMMENT 'owner',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user` (`uid`),
  KEY `customer` (`ctm_id`),
  CONSTRAINT `process_ibfk_1` FOREIGN KEY (`ctm_id`) REFERENCES `customer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process`
--

LOCK TABLES `process` WRITE;
/*!40000 ALTER TABLE `process` DISABLE KEYS */;
INSERT INTO `process` VALUES (32,'Housing',1111,2,1111,'USA','ssss','1111','Piece1111','AA',4,'<p>Prozesuaren deskripzioren bat</p>',1,'2019-01-21 18:03:21','2019-01-21 18:03:21'),(33,'Prueba_1i',900252532,6,20570,'Bergara','SP560','80033844383','CosaMaravillosa','BB',4,NULL,16,'2019-01-25 09:22:39','2019-01-25 09:22:39'),(34,'Llave Rueda',156654568,7,1515,'bergara','SACMA SP470','E1515-001','Key Body','A',4,'<p>fafaafaaa</p>',14,'2019-01-28 08:41:55','2019-01-28 08:41:55'),(35,'AITOR FROGAKAA',1552,7,1515,'beragara','2225','112','112','AA',4,'<p>sadfa</p>',13,'2019-02-08 11:53:53','2019-02-08 11:53:53'),(36,'Prueba_2i',3,6,33405,'Bergara','SP560','80033844384','CosaMaravillosa2','AA',4,NULL,16,'2019-03-09 05:45:16','2019-03-09 05:45:16'),(38,'aaa',1111,11,1111,'1111','aaa','1111','1111','AA',4,NULL,1,'2019-03-28 20:17:40','2019-03-28 20:17:40');
/*!40000 ALTER TABLE `process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_action`
--

DROP TABLE IF EXISTS `process_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `pcs_id` int(11) NOT NULL COMMENT 'process',
  `src_id` int(11) NOT NULL COMMENT 'source',
  `name` varchar(255) NOT NULL,
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `src-process` (`pcs_id`,`src_id`,`discr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_action`
--

LOCK TABLES `process_action` WRITE;
/*!40000 ALTER TABLE `process_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint`
--

DROP TABLE IF EXISTS `process_hint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stg_id` int(11) NOT NULL COMMENT 'stage',
  `type_id` int(11) DEFAULT NULL COMMENT 'error type',
  `uid` int(11) NOT NULL COMMENT 'owner',
  `prior` int(2) NOT NULL DEFAULT '1' COMMENT 'priority',
  `text` varchar(255) DEFAULT NULL,
  `who` varchar(255) DEFAULT NULL COMMENT 'who modelizes',
  `whn` timestamp NULL DEFAULT NULL COMMENT 'when modelizes',
  `eff` text COMMENT 'effect',
  `prev` text COMMENT 'prevention',
  `state` int(2) NOT NULL DEFAULT '0' COMMENT 'modelize state',
  `descr` text,
  `cmm_c` int(4) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `stg_id` (`stg_id`),
  KEY `user` (`uid`),
  KEY `error_type` (`type_id`),
  CONSTRAINT `process_hint_ibfk_1` FOREIGN KEY (`stg_id`) REFERENCES `process_stage` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_ibfk_2` FOREIGN KEY (`type_id`) REFERENCES `process_hint_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_ibfk_3` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=326 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint`
--

LOCK TABLES `process_hint` WRITE;
/*!40000 ALTER TABLE `process_hint` DISABLE KEYS */;
INSERT INTO `process_hint` VALUES (116,90,63,1,4,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-21 18:09:38','2019-01-21 18:09:38'),(120,116,64,16,1,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-25 09:25:54','2019-01-25 09:25:54'),(121,117,65,16,1,NULL,NULL,NULL,NULL,NULL,0,'Rebaba en la zona del expulsor',0,'2019-01-25 09:40:45','2019-01-25 09:40:45'),(122,117,66,16,3,NULL,NULL,NULL,NULL,NULL,0,'Se genera un escalón',0,'2019-01-25 09:42:57','2019-01-25 09:42:57'),(129,122,67,16,99,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-25 09:50:50','2019-01-25 09:50:50'),(130,126,67,16,99,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-25 09:54:26','2019-01-25 09:54:26'),(131,125,65,16,1,NULL,NULL,NULL,NULL,NULL,0,'Rebaba en la zona del expulsor',0,'2019-01-25 09:54:26','2019-01-25 09:54:26'),(132,125,66,16,3,NULL,NULL,NULL,NULL,NULL,0,'Se genera un escalón',0,'2019-01-25 09:54:26','2019-01-25 09:54:26'),(133,124,64,16,1,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-25 09:54:26','2019-01-25 09:54:26'),(140,133,68,14,3,NULL,NULL,NULL,NULL,NULL,0,'rebabas',0,'2019-01-28 10:28:31','2019-01-28 10:28:31'),(141,133,69,14,5,NULL,NULL,NULL,NULL,NULL,0,'problemas con el tope',0,'2019-01-28 10:32:08','2019-01-28 10:32:08'),(142,134,70,14,3,NULL,NULL,NULL,NULL,NULL,0,'La pieza se escapa del utillaje',0,'2019-01-28 10:58:19','2019-01-28 10:58:19'),(143,134,71,14,5,NULL,NULL,NULL,NULL,NULL,0,'La pieza se pega al utillaje',0,'2019-01-28 11:06:04','2019-01-28 11:06:04'),(144,135,72,14,5,NULL,NULL,NULL,NULL,NULL,0,'Pieza deformada en varias zonas',0,'2019-01-28 11:10:29','2019-01-28 11:10:29'),(146,135,72,14,5,NULL,NULL,NULL,NULL,NULL,0,'Pieza deformada en varias zonas',0,'2019-01-28 11:16:33','2019-01-28 11:16:33'),(147,136,76,14,3,NULL,NULL,NULL,NULL,NULL,0,'Cara de extrusión irregular',0,'2019-01-28 11:22:58','2019-01-28 11:22:58'),(148,136,76,14,4,NULL,NULL,NULL,NULL,NULL,0,'Cara de extrusión irregular',0,'2019-01-29 09:44:47','2019-01-29 09:44:47'),(149,136,77,14,3,NULL,NULL,NULL,NULL,NULL,0,'Rebaba en la zona central',0,'2019-01-29 09:48:27','2019-01-29 09:48:27'),(150,136,77,14,2,NULL,NULL,NULL,NULL,NULL,0,'rebaba en la zona central',0,'2019-01-29 09:50:15','2019-01-29 09:50:15'),(151,136,78,14,4,NULL,NULL,NULL,NULL,NULL,0,'Extrusión escasa',0,'2019-01-29 09:51:49','2019-01-29 09:51:49'),(152,136,79,14,3,NULL,NULL,NULL,NULL,NULL,0,'Rebaba  en Ø18,7',0,'2019-01-29 09:56:51','2019-01-29 09:56:51'),(153,137,80,14,5,NULL,NULL,NULL,NULL,NULL,0,'Diámetro alto en cota 14,94',0,'2019-01-29 10:11:53','2019-01-29 10:11:53'),(154,137,81,14,5,NULL,NULL,NULL,NULL,NULL,0,'Superficie irregular desde extrusión',0,'2019-01-29 10:13:23','2019-01-29 10:13:23'),(155,137,82,14,5,NULL,NULL,NULL,NULL,NULL,0,'La altura es pequeña',0,'2019-01-29 10:14:35','2019-01-29 10:14:35'),(156,137,83,14,3,NULL,NULL,NULL,NULL,NULL,0,'Generación de cámara de aceite',0,'2019-01-29 10:16:34','2019-01-29 10:16:34'),(157,137,84,14,5,NULL,NULL,NULL,NULL,NULL,0,'Al extruir cierra y se rompe calibre punzón',0,'2019-01-29 10:17:43','2019-01-29 10:17:43'),(158,137,85,14,2,NULL,NULL,NULL,NULL,NULL,0,'Al extruir la cara plana no queda plana',0,'2019-01-29 10:19:34','2019-01-29 10:19:34'),(179,137,86,14,2,NULL,NULL,NULL,NULL,NULL,0,'Falta de llenado resultante insuficiente para estampar hexagono',0,'2019-01-29 11:13:20','2019-01-29 11:13:20'),(180,137,86,14,4,NULL,NULL,NULL,NULL,NULL,0,'Falta de llenado resultante insuficiente para estampar hexagono',0,'2019-01-29 11:14:56','2019-01-29 11:14:56'),(181,137,86,14,4,NULL,NULL,NULL,NULL,NULL,0,'Falta de llenado resultante insuficiente para estampar hexagono',0,'2019-01-29 11:16:50','2019-01-29 11:16:50'),(217,153,80,14,5,NULL,NULL,NULL,NULL,NULL,0,'Diámetro alto en cota 14,94',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(218,153,81,14,5,NULL,NULL,NULL,NULL,NULL,0,'Superficie irregular desde extrusión',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(219,153,82,14,5,NULL,NULL,NULL,NULL,NULL,0,'La altura es pequeña',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(220,153,83,14,3,NULL,NULL,NULL,NULL,NULL,0,'Generación de cámara de aceite',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(221,153,84,14,5,NULL,NULL,NULL,NULL,NULL,0,'Al extruir cierra y se rompe calibre punzón',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(222,153,85,14,2,NULL,NULL,NULL,NULL,NULL,0,'Al extruir la cara plana no queda plana',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(223,153,86,14,2,NULL,NULL,NULL,NULL,NULL,0,'Falta de llenado resultante insuficiente para estampar hexagono',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(224,153,86,14,4,NULL,NULL,NULL,NULL,NULL,0,'Falta de llenado resultante insuficiente para estampar hexagono',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(225,153,86,14,4,NULL,NULL,NULL,NULL,NULL,0,'Falta de llenado resultante insuficiente para estampar hexagono',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(226,152,76,14,3,NULL,NULL,NULL,NULL,NULL,0,'Cara de extrusión irregular',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(227,152,76,14,4,NULL,NULL,NULL,NULL,NULL,0,'Cara de extrusión irregular',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(228,152,77,14,3,NULL,NULL,NULL,NULL,NULL,0,'Rebaba en la zona central',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(229,152,77,14,2,NULL,NULL,NULL,NULL,NULL,0,'rebaba en la zona central',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(230,152,78,14,4,NULL,NULL,NULL,NULL,NULL,0,'Extrusión escasa',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(231,152,79,14,3,NULL,NULL,NULL,NULL,NULL,0,'Rebaba  en Ø18,7',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(232,151,72,14,5,NULL,NULL,NULL,NULL,NULL,0,'Pieza deformada en varias zonas',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(233,151,72,14,5,NULL,NULL,NULL,NULL,NULL,0,'Pieza deformada en varias zonas',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(234,150,70,14,3,NULL,NULL,NULL,NULL,NULL,0,'La pieza se escapa del utillaje',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(235,150,71,14,5,NULL,NULL,NULL,NULL,NULL,0,'La pieza se pega al utillaje',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(236,149,68,14,3,NULL,NULL,NULL,NULL,NULL,0,'rebabas',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(237,149,69,14,5,NULL,NULL,NULL,NULL,NULL,0,'problemas con el tope',0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(259,159,87,14,5,NULL,NULL,NULL,NULL,NULL,0,'Falta de llenado en los vértices',0,'2019-01-30 11:51:09','2019-01-30 11:51:09'),(260,159,88,14,5,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-30 11:53:01','2019-01-30 11:53:01'),(261,159,89,14,3,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-30 11:54:32','2019-01-30 11:54:32'),(262,159,90,14,3,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-30 11:55:23','2019-01-30 11:55:23'),(263,159,91,14,4,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-30 11:56:28','2019-01-30 11:56:28'),(264,159,100,14,4,NULL,NULL,NULL,NULL,NULL,0,'No escuadra bien',0,'2019-01-30 12:02:47','2019-01-30 12:02:47'),(265,159,92,14,3,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-30 12:04:49','2019-01-30 12:04:49'),(267,159,93,14,4,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-30 12:08:04','2019-01-30 12:08:04'),(272,159,97,14,3,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-30 12:15:07','2019-01-30 12:15:07'),(273,159,98,14,4,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-30 12:16:42','2019-01-30 12:16:42'),(274,159,99,14,4,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-01-30 12:25:58','2019-01-30 12:25:58'),(275,160,101,13,3,NULL,NULL,NULL,NULL,NULL,0,'material irregular',0,'2019-02-08 12:09:23','2019-02-08 12:09:23'),(276,160,69,13,5,NULL,NULL,NULL,NULL,NULL,0,'problemas con el tope',0,'2019-02-08 12:10:38','2019-02-08 12:10:38'),(277,160,103,13,5,NULL,NULL,NULL,NULL,NULL,0,'Riesgos de caida en 3,4 o 5',0,'2019-02-08 12:12:48','2019-02-08 12:12:48'),(278,161,63,13,3,NULL,NULL,NULL,NULL,NULL,0,'la pieza se pega al utillaje',0,'2019-02-08 12:15:14','2019-02-08 12:15:14'),(279,162,104,13,3,NULL,NULL,NULL,NULL,NULL,0,'Pieza descentrada',0,'2019-02-08 12:19:41','2019-02-08 12:19:41'),(280,163,105,13,4,NULL,NULL,NULL,NULL,NULL,0,'Romper el punzón en la extracción',0,'2019-02-11 09:55:50','2019-02-11 09:55:50'),(281,163,106,13,4,NULL,NULL,NULL,NULL,NULL,0,'Comprimir punzón',0,'2019-02-11 09:56:37','2019-02-11 09:56:37'),(282,163,107,13,3,NULL,NULL,NULL,NULL,NULL,0,'Riesgo de camara entre parte recta y cono',0,'2019-02-11 09:59:13','2019-02-11 09:59:13'),(283,163,108,13,4,NULL,NULL,NULL,NULL,NULL,0,'Rotura de matriz',0,'2019-02-11 10:00:30','2019-02-11 10:00:30'),(284,163,109,13,3,NULL,NULL,NULL,NULL,NULL,0,'Rebabas en parte inferior entre punzón, casquillo o matriz',0,'2019-02-11 10:01:55','2019-02-11 10:01:55'),(285,163,110,13,4,NULL,NULL,NULL,NULL,NULL,0,'Dificultades de extracción',0,'2019-02-11 10:02:59','2019-02-11 10:02:59'),(286,163,111,13,4,NULL,NULL,NULL,NULL,NULL,0,'Rotura de punzón o casquillo',0,'2019-02-11 10:06:16','2019-02-11 10:06:16'),(287,163,112,13,5,NULL,NULL,NULL,NULL,NULL,0,'Rebaba entre casquillo superior y matriz',0,'2019-02-11 10:08:33','2019-02-11 10:08:33'),(288,163,113,13,5,NULL,NULL,NULL,NULL,NULL,0,'No haber forma de controlar el material',0,'2019-02-11 10:09:47','2019-02-11 10:09:47'),(289,163,114,13,5,NULL,NULL,NULL,NULL,NULL,0,'La pieza necesita extracción positiva',0,'2019-02-11 10:10:50','2019-02-11 10:10:50'),(290,164,115,13,4,NULL,NULL,NULL,NULL,NULL,0,'Dificultad de introducción de pieza',0,'2019-02-11 10:26:24','2019-02-11 10:26:24'),(291,164,110,13,4,NULL,NULL,NULL,NULL,NULL,0,'Dificultad de recoger la pieza estampada',0,'2019-02-11 10:27:19','2019-02-11 10:27:19'),(292,164,116,13,4,NULL,NULL,NULL,NULL,NULL,0,'Chaflán de entrada no formado',0,'2019-02-11 10:29:10','2019-02-11 10:29:10'),(293,165,117,13,4,NULL,NULL,NULL,NULL,NULL,0,'Corte no centrado',0,'2019-02-11 10:34:24','2019-02-11 10:34:24'),(294,166,117,13,4,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-02-12 07:07:54','2019-02-12 07:07:54'),(295,173,117,13,4,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(296,172,117,13,4,NULL,NULL,NULL,NULL,NULL,0,'Corte no centrado',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(297,171,115,13,4,NULL,NULL,NULL,NULL,NULL,0,'Dificultad de introducción de pieza',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(298,171,110,13,4,NULL,NULL,NULL,NULL,NULL,0,'Dificultad de recoger la pieza estampada',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(299,171,116,13,4,NULL,NULL,NULL,NULL,NULL,0,'Chaflán de entrada no formado',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(300,170,105,13,4,NULL,NULL,NULL,NULL,NULL,0,'Romper el punzón en la extracción',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(301,170,106,13,4,NULL,NULL,NULL,NULL,NULL,0,'Comprimir punzón',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(302,170,107,13,3,NULL,NULL,NULL,NULL,NULL,0,'Riesgo de camara entre parte recta y cono',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(303,170,108,13,4,NULL,NULL,NULL,NULL,NULL,0,'Rotura de matriz',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(304,170,109,13,3,NULL,NULL,NULL,NULL,NULL,0,'Rebabas en parte inferior entre punzón, casquillo o matriz',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(305,170,110,13,4,NULL,NULL,NULL,NULL,NULL,0,'Dificultades de extracción',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(306,170,111,13,4,NULL,NULL,NULL,NULL,NULL,0,'Rotura de punzón o casquillo',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(307,170,112,13,5,NULL,NULL,NULL,NULL,NULL,0,'Rebaba entre casquillo superior y matriz',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(308,170,113,13,5,NULL,NULL,NULL,NULL,NULL,0,'No haber forma de controlar el material',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(309,170,114,13,5,NULL,NULL,NULL,NULL,NULL,0,'La pieza necesita extracción positiva',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(310,169,104,13,3,NULL,NULL,NULL,NULL,NULL,0,'Pieza descentrada',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(311,168,63,13,3,NULL,NULL,NULL,NULL,NULL,0,'la pieza se pega al utillaje',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(312,167,101,13,3,NULL,NULL,NULL,NULL,NULL,0,'material irregular',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(313,167,69,13,5,NULL,NULL,NULL,NULL,NULL,0,'problemas con el tope',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(314,167,103,13,5,NULL,NULL,NULL,NULL,NULL,0,'Riesgos de caida en 3,4 o 5',0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(322,178,68,16,1,NULL,NULL,NULL,NULL,NULL,0,'Rebabas en la herramienta por no redondear el perfil',0,'2019-03-09 05:48:20','2019-03-09 05:48:20'),(323,179,66,16,0,NULL,NULL,NULL,NULL,NULL,0,'asf',0,'2019-03-09 05:50:45','2019-03-09 05:50:45'),(325,184,119,1,2,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-03-28 20:18:06','2019-03-28 20:18:06');
/*!40000 ALTER TABLE `process_hint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_context`
--

DROP TABLE IF EXISTS `process_hint_context`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_context` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hint_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `cmm_c` int(4) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_context`
--

LOCK TABLES `process_hint_context` WRITE;
/*!40000 ALTER TABLE `process_hint_context` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_hint_context` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_influence`
--

DROP TABLE IF EXISTS `process_hint_influence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_influence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'user',
  `rsn_id` int(11) NOT NULL COMMENT 'reason',
  `cmm_c` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_influence`
--

LOCK TABLES `process_hint_influence` WRITE;
/*!40000 ALTER TABLE `process_hint_influence` DISABLE KEYS */;
INSERT INTO `process_hint_influence` VALUES (5,1,7,0,'2019-03-28 20:35:12','2019-03-28 20:35:12'),(6,1,7,0,'2019-03-28 20:35:25','2019-03-28 20:35:25'),(7,1,8,0,'2019-03-28 20:37:21','2019-03-28 20:37:21');
/*!40000 ALTER TABLE `process_hint_influence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_reason`
--

DROP TABLE IF EXISTS `process_hint_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_reason` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `hint_id` int(11) NOT NULL,
  `cmm_c` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_reason`
--

LOCK TABLES `process_hint_reason` WRITE;
/*!40000 ALTER TABLE `process_hint_reason` DISABLE KEYS */;
INSERT INTO `process_hint_reason` VALUES (7,1,325,0,'2019-03-28 20:35:04','2019-03-28 20:35:04'),(8,1,325,0,'2019-03-28 20:35:48','2019-03-28 20:35:48');
/*!40000 ALTER TABLE `process_hint_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_relation`
--

DROP TABLE IF EXISTS `process_hint_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_relation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) NOT NULL,
  `ctx_id` int(11) NOT NULL,
  `descr` text,
  `cmm_c` int(4) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_relation`
--

LOCK TABLES `process_hint_relation` WRITE;
/*!40000 ALTER TABLE `process_hint_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_hint_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_simulation`
--

DROP TABLE IF EXISTS `process_hint_simulation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_simulation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) NOT NULL COMMENT 'source',
  `state` int(2) NOT NULL DEFAULT '0',
  `who` text,
  `whn` text,
  `eff` text,
  `prev` text,
  `descr` text,
  `cmm_c` int(4) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user` (`uid`),
  KEY `source` (`src_id`),
  CONSTRAINT `process_hint_simulation_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_simulation_ibfk_2` FOREIGN KEY (`src_id`) REFERENCES `process_hint_influence` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_simulation`
--

LOCK TABLES `process_hint_simulation` WRITE;
/*!40000 ALTER TABLE `process_hint_simulation` DISABLE KEYS */;
INSERT INTO `process_hint_simulation` VALUES (5,1,5,0,NULL,NULL,NULL,NULL,NULL,0,'2019-03-28 20:36:27','2019-03-28 20:36:27'),(6,1,5,2,'Norbaitek','2019-03-27 00:00:00',NULL,NULL,NULL,0,'2019-03-28 20:36:38','2019-03-28 20:36:38'),(7,1,6,-2,NULL,NULL,NULL,NULL,NULL,0,'2019-03-28 20:36:54','2019-03-28 20:36:54');
/*!40000 ALTER TABLE `process_hint_simulation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_type`
--

DROP TABLE IF EXISTS `process_hint_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `op_id` int(11) NOT NULL COMMENT 'operation',
  `prior` int(2) NOT NULL DEFAULT '0',
  `h_count` int(11) NOT NULL DEFAULT '0' COMMENT 'error count',
  `title` varchar(255) NOT NULL,
  `descr` text,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `operation` (`op_id`),
  CONSTRAINT `process_hint_type_ibfk_1` FOREIGN KEY (`op_id`) REFERENCES `process_op` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_type`
--

LOCK TABLES `process_hint_type` WRITE;
/*!40000 ALTER TABLE `process_hint_type` DISABLE KEYS */;
INSERT INTO `process_hint_type` VALUES (63,117,2,2,'La pieza se pega al utillaje',NULL,1,'2019-01-21 18:09:37','2019-01-21 18:09:37'),(64,95,1,3,'Error de Corte normal',NULL,16,'2019-01-25 09:25:51','2019-01-25 09:25:51'),(65,96,1,1,'Rebaba',NULL,16,'2019-01-25 09:40:23','2019-01-25 09:40:23'),(66,96,2,2,'Escalón en la zona de punteo',NULL,16,'2019-01-25 09:42:48','2019-01-25 09:42:48'),(67,97,3,1,'Rayas en la pieza',NULL,16,'2019-01-25 09:50:32','2019-01-25 09:50:32'),(68,95,3,3,'rebabas',NULL,14,'2019-01-28 08:46:56','2019-01-28 08:46:56'),(69,95,5,3,'problemas con el tope',NULL,13,'2019-01-28 08:55:29','2019-01-28 08:55:29'),(70,165,3,2,'La pieza se escapa del utillaje',NULL,13,'2019-01-28 09:50:08','2019-01-28 09:50:08'),(71,165,5,2,'La pieza se pega al utillaje',NULL,13,'2019-01-28 09:52:26','2019-01-28 09:52:26'),(72,109,5,4,'Pieza deformada en varias zonas',NULL,13,'2019-01-28 09:58:52','2019-01-28 09:58:52'),(73,109,5,1,'Pieza deformada en varias zonas',NULL,13,'2019-01-28 10:01:24','2019-01-28 10:01:24'),(74,109,5,1,'Pieza viene grande de anterior estación',NULL,13,'2019-01-28 11:13:28','2019-01-28 11:13:28'),(75,129,3,1,'cara de estrusión irregular',NULL,13,'2019-01-28 11:22:35','2019-01-28 11:22:35'),(76,129,3,1,'Cara de extrusión irregular',NULL,13,'2019-01-28 11:23:22','2019-01-28 11:23:22'),(77,129,3,2,'Rebaba en la zona central',NULL,13,'2019-01-29 09:48:19','2019-01-29 09:48:19'),(78,129,4,1,'Extrusión escasa',NULL,13,'2019-01-29 09:51:43','2019-01-29 09:51:43'),(79,120,3,1,'Rebaba  en Ø18,7',NULL,13,'2019-01-29 09:56:39','2019-01-29 09:56:39'),(80,97,5,1,'Diámetro alto en cota 14,94',NULL,13,'2019-01-29 10:11:50','2019-01-29 10:11:50'),(81,97,5,1,'Superficie irregular desde extrusión',NULL,13,'2019-01-29 10:13:20','2019-01-29 10:13:20'),(82,157,5,1,'La altura es pequeña',NULL,13,'2019-01-29 10:14:31','2019-01-29 10:14:31'),(83,157,3,1,'Generación de cámara de aceite',NULL,13,'2019-01-29 10:16:27','2019-01-29 10:16:27'),(84,157,5,1,'Al extruir cierra y se rompe calibre punzón',NULL,13,'2019-01-29 10:17:40','2019-01-29 10:17:40'),(85,157,2,1,'Al extruir la cara plana no queda plana',NULL,13,'2019-01-29 10:19:32','2019-01-29 10:19:32'),(86,122,4,4,'Falta de llenado resultante insuficiente para estampar hexagono',NULL,13,'2019-01-29 10:22:24','2019-01-29 10:22:24'),(87,160,5,2,'Falta de llenado en los vértices',NULL,13,'2019-01-30 10:55:04','2019-01-30 10:55:04'),(88,160,5,2,'Rebaba en zona inferior del hexágono',NULL,13,'2019-01-30 10:57:16','2019-01-30 10:57:16'),(89,160,3,2,'Entre caras hexagonal demasiado grande',NULL,13,'2019-01-30 10:59:41','2019-01-30 10:59:41'),(90,160,3,2,'Rayas en caras hexagonales',NULL,13,'2019-01-30 11:00:55','2019-01-30 11:00:55'),(91,109,4,1,'Se trefila por encima de la cota nominal',NULL,13,'2019-01-30 11:10:38','2019-01-30 11:10:38'),(92,109,3,3,'Falta de llenado',NULL,13,'2019-01-30 11:13:33','2019-01-30 11:13:33'),(93,109,4,2,'Rebaba por exceso de llenado',NULL,13,'2019-01-30 11:14:49','2019-01-30 11:14:49'),(97,129,3,2,'Diámetro excesivo',NULL,13,'2019-01-30 11:31:31','2019-01-30 11:31:31'),(98,129,4,2,'Diámetro irregular, no hay cilindricidad',NULL,13,'2019-01-30 11:33:39','2019-01-30 11:33:39'),(99,129,4,2,'Longitud corta',NULL,13,'2019-01-30 11:35:23','2019-01-30 11:35:23'),(100,109,4,1,'no escuadra bien',NULL,13,'2019-01-30 12:02:36','2019-01-30 12:02:36'),(101,95,3,2,'material irregular',NULL,13,'2019-02-08 12:09:16','2019-02-08 12:09:16'),(102,95,5,0,'trasnsporte',NULL,13,'2019-02-08 12:11:46','2019-02-08 12:11:46'),(103,117,5,1,'Riesgos de caida en 3,4 o 5',NULL,13,'2019-02-08 12:12:44','2019-02-08 12:12:44'),(104,104,3,1,'Pieza descentrada',NULL,13,'2019-02-08 12:19:35','2019-02-08 12:19:35'),(105,166,4,1,'Romper el punzón en la extracción',NULL,13,'2019-02-11 09:55:46','2019-02-11 09:55:46'),(106,166,4,1,'Comprimir punzón',NULL,13,'2019-02-11 09:56:35','2019-02-11 09:56:35'),(107,160,3,1,'Riesgo de camara entre parte recta y cono',NULL,13,'2019-02-11 09:59:10','2019-02-11 09:59:10'),(108,160,4,1,'Rotura de matriz',NULL,13,'2019-02-11 10:00:19','2019-02-11 10:00:19'),(109,160,3,1,'Rebabas en parte inferior entre punzón, casquillo o matriz',NULL,13,'2019-02-11 10:01:53','2019-02-11 10:01:53'),(110,160,4,2,'Dificultades de extracción',NULL,13,'2019-02-11 10:02:55','2019-02-11 10:02:55'),(111,131,4,1,'Rotura de punzón o casquillo',NULL,13,'2019-02-11 10:06:13','2019-02-11 10:06:13'),(112,131,5,1,'Rebaba entre casquillo superior y matriz',NULL,13,'2019-02-11 10:08:31','2019-02-11 10:08:31'),(113,131,5,1,'No haber forma de controlar el material',NULL,13,'2019-02-11 10:09:44','2019-02-11 10:09:44'),(114,131,5,1,'La pieza necesita extracción positiva',NULL,13,'2019-02-11 10:10:44','2019-02-11 10:10:44'),(115,160,4,1,'Dificultad de introducción de pieza',NULL,13,'2019-02-11 10:26:14','2019-02-11 10:26:14'),(116,157,4,1,'Chaflán de entrada no formado',NULL,13,'2019-02-11 10:28:56','2019-02-11 10:28:56'),(117,161,4,2,'Corte no centrado',NULL,13,'2019-02-11 10:34:21','2019-02-11 10:34:21'),(119,182,0,2,'Error 1.1','Pellentesque pulvinar porttitor dui ut faucibus. Lorem ipsum dolor sit amet, consectetur adipiscing elit',1,'2019-03-28 20:02:05','2019-03-28 20:02:05'),(120,183,1,1,'Error 2.1',NULL,1,'2019-03-28 20:27:02','2019-03-28 20:27:02'),(121,183,0,1,'Error 3.1',NULL,1,'2019-03-28 20:31:04','2019-03-28 20:31:04'),(122,183,6,1,'Error 3.2',NULL,1,'2019-03-28 20:31:20','2019-03-28 20:31:20'),(123,182,2,1,'Error 1.2',NULL,1,'2019-03-28 20:45:50','2019-03-28 20:45:50');
/*!40000 ALTER TABLE `process_hint_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_material`
--

DROP TABLE IF EXISTS `process_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `prior` int(2) NOT NULL DEFAULT '0',
  `descr` text,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_material`
--

LOCK TABLES `process_material` WRITE;
/*!40000 ALTER TABLE `process_material` DISABLE KEYS */;
INSERT INTO `process_material` VALUES (5,'C8C',1,'<p>Materialaren deskripzio bat</p>',1,'2019-01-21 19:02:35','2019-01-21 19:02:35'),(6,'42CrMo4',4,NULL,16,'2019-01-25 10:21:26','2019-01-25 10:21:26');
/*!40000 ALTER TABLE `process_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op`
--

DROP TABLE IF EXISTS `process_op`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `descr` text,
  `type_id` int(11) NOT NULL COMMENT 'operation type',
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `operation_type` (`type_id`),
  KEY `user` (`uid`),
  CONSTRAINT `process_op_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `process_op_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_op_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op`
--

LOCK TABLES `process_op` WRITE;
/*!40000 ALTER TABLE `process_op` DISABLE KEYS */;
INSERT INTO `process_op` VALUES (95,'Standard',NULL,8,1,'2018-12-16 16:51:24','2018-12-16 16:51:24'),(96,'En radio',NULL,9,1,'2018-12-16 16:53:54','2018-12-16 16:53:54'),(97,'Severa (50-70%)','<ul><li>No cilíndricas. (estrias, ranuras, cuadrados etc)</li><li>Con ángulo en vez de radio</li><li>Grandes longitudes de extrusión (L&gt;3d??)</li><li>Con estacion previa de preparación</li><li>Distribuida entre buterola/matriz<br/></li></ul>',10,1,'2018-12-16 16:54:54','2018-12-16 16:54:54'),(98,'En ángulo',NULL,10,1,'2018-12-16 16:55:25','2018-12-16 16:55:25'),(99,'Severa (50-70%) + En ángulo','<p>Deskripzio desbesdin bat batura honentzako</p>',10,1,'2018-12-16 16:55:44','2018-12-16 16:55:44'),(100,'Extracción','<p>Mecanismo que posibilita la extracción de la pieza de los utillajes.<br/></p>',11,1,'2018-12-16 16:59:05','2018-12-16 16:59:05'),(101,'Introducción','<p>Mecanismo que guia la introduccón de la pieza hasta su posición de conformado.<br/></p>',11,1,'2018-12-16 16:59:21','2018-12-16 16:59:21'),(102,'Sujeción','<p>Conjunto de elementos que sujetan la pieza al salir, meter y mover la pieza entre estaciones.<br/></p>',11,1,'2018-12-16 16:59:36','2018-12-16 16:59:36'),(103,'Matriz abierta','<p>Tipo de recalcado usando matrices segmentadas con geometrias con contrasalidas.<br/></p>',12,1,'2018-12-16 17:00:47','2018-12-16 17:00:47'),(104,'Abierto','<p>Aumentar la sección de una parte del material sin sujetar el material dentro de los utillajes. Límite de recalcado libre r=2<br/></p>',12,1,'2018-12-16 17:01:28','2018-12-16 17:01:28'),(105,'Cerrado','<p>Aumentar la seccion de una parte del material sujetando el material dentro de los utillajes. Límite de recalcado libre r=2<br/></p>',12,1,'2018-12-16 17:01:43','2018-12-16 17:01:43'),(108,'Grandes deformaciones',NULL,8,1,'2018-12-16 17:03:41','2018-12-16 17:03:41'),(109,'Escuadrado',NULL,9,1,'2018-12-16 17:04:02','2018-12-16 17:04:02'),(111,'Punzonado',NULL,9,1,'2018-12-16 17:04:36','2018-12-16 17:04:36'),(117,'De paso',NULL,11,1,'2018-12-16 18:10:05','2018-12-16 18:10:05'),(120,'Desde parte fija',NULL,14,1,'2018-12-16 18:13:13','2018-12-16 18:13:13'),(122,'Desde parte móvil',NULL,14,1,'2018-12-16 18:13:54','2018-12-16 18:13:54'),(129,'Standard (30-50%)',NULL,10,15,'2018-12-17 06:09:55','2018-12-17 06:09:55'),(131,'Severa (50-70%) + Directa',NULL,10,1,'2018-12-17 14:16:13','2018-12-17 14:16:13'),(132,'Estandar',NULL,11,1,'2018-12-17 14:36:07','2018-12-17 14:36:07'),(157,'Cerrada','<p>Extrusión inversa con todo el material contenido</p>',16,15,'2018-12-26 14:51:31','2018-12-26 14:51:31'),(158,'Parcialmente cerrada','<p>Con herramienta flotante</p>',16,15,'2018-12-26 14:52:07','2018-12-26 14:52:07'),(159,'Abierta','<p>El material no está radialmente contenido. </p>',16,15,'2018-12-26 14:52:55','2018-12-26 14:52:55'),(160,'Recalcado de preforma',NULL,12,15,'2018-12-26 14:57:00','2018-12-26 14:57:00'),(161,'Recorte','<p>Eliminación del sobrante de material<br/></p>',17,15,'2018-12-26 15:00:24','2018-12-26 15:00:24'),(162,'Parcial','<p>Operación previa al recortado total donde se recorta material sin hacerlo pasante</p>',17,15,'2018-12-26 15:01:44','2018-12-26 15:01:44'),(163,'Piercing','<p>Eliminación de pepita</p>',17,15,'2018-12-26 15:10:21','2018-12-26 15:10:21'),(165,'Estación de paso','<p>Estación de paso</p>',18,13,'2019-01-28 09:49:10','2019-01-28 09:49:10'),(166,'Taladrado zona inferior','<p>Taladrado zona inferior</p>',19,13,'2019-02-11 09:50:32','2019-02-11 09:50:32'),(167,'Taladrado zona superior','<p>Taladrado zona superior<span id=\"selectionBoundary_1549882374457_6413005605141959\" class=\"rangySelectionBoundary\">&#65279;</span></p>',19,13,'2019-02-11 09:50:50','2019-02-11 09:50:50'),(168,'Directa',NULL,10,1,'2019-03-08 11:56:43','2019-03-08 11:56:43'),(182,'Prueba standard','<p></p><p>Pellentesque felis urna, sollicitudin ac pharetra non</p>',21,1,'2019-03-28 19:56:28','2019-03-28 19:56:28'),(183,'Operación de prueba','<p>Suspendisse potenti. Ut ullamcorper velit eget magna cursus convallis<br/></p>',21,1,'2019-03-28 19:57:12','2019-03-28 19:57:12');
/*!40000 ALTER TABLE `process_op` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op_rel`
--

DROP TABLE IF EXISTS `process_op_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op_rel` (
  `parent_id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL,
  UNIQUE KEY `rel` (`parent_id`,`child_id`),
  KEY `child_id` (`child_id`),
  CONSTRAINT `process_op_rel_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `process_op` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_op_rel_ibfk_2` FOREIGN KEY (`child_id`) REFERENCES `process_op` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op_rel`
--

LOCK TABLES `process_op_rel` WRITE;
/*!40000 ALTER TABLE `process_op_rel` DISABLE KEYS */;
INSERT INTO `process_op_rel` VALUES (97,99),(98,99),(97,131),(168,131);
/*!40000 ALTER TABLE `process_op_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op_stg_rel`
--

DROP TABLE IF EXISTS `process_op_stg_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op_stg_rel` (
  `op_id` int(11) NOT NULL,
  `stg_id` int(11) NOT NULL,
  UNIQUE KEY `op_stg_rel` (`op_id`,`stg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op_stg_rel`
--

LOCK TABLES `process_op_stg_rel` WRITE;
/*!40000 ALTER TABLE `process_op_stg_rel` DISABLE KEYS */;
INSERT INTO `process_op_stg_rel` VALUES (89,95),(90,117),(91,109),(92,109),(93,109),(94,96),(116,95),(117,96),(122,97),(123,104),(124,95),(125,96),(126,97),(127,104),(133,95),(134,165),(135,109),(136,120),(136,129),(137,97),(137,122),(137,157),(149,95),(150,165),(151,109),(152,120),(152,129),(153,97),(153,122),(153,157),(159,109),(159,129),(159,160),(160,95),(160,117),(161,117),(162,104),(163,131),(163,160),(163,166),(164,157),(164,160),(165,161),(166,161),(167,95),(167,117),(168,117),(169,104),(170,131),(170,160),(170,166),(171,157),(171,160),(172,161),(173,161),(178,95),(179,96),(184,182);
/*!40000 ALTER TABLE `process_op_stg_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op_type`
--

DROP TABLE IF EXISTS `process_op_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `descr` text,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user` (`uid`),
  CONSTRAINT `process_op_type_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op_type`
--

LOCK TABLES `process_op_type` WRITE;
/*!40000 ALTER TABLE `process_op_type` DISABLE KEYS */;
INSERT INTO `process_op_type` VALUES (8,'Corte','<p>Corte transversal del alambre ya enderezado a la longitud deseada, es importante el acabado de la zona deformada para evitar problemas posteriores.<br/></p>',1,'2018-12-16 16:50:37','2018-12-16 16:50:37'),(9,'Preparación','<p>Deskripzio bat hemen<br/></p>',1,'2018-12-16 16:53:47','2018-12-16 16:53:47'),(10,'Extrusión Hacia Delante','<p>Forward extrusion</p>',1,'2018-12-16 16:54:31','2018-12-16 16:54:31'),(11,'Transporte','<p>Deskripzio bat hemen<br/></p>',1,'2018-12-16 16:58:42','2018-12-16 16:58:42'),(12,'Recalcado','<p>Deskripzio bat hemen<br/></p>',1,'2018-12-16 16:59:56','2018-12-16 16:59:56'),(14,'Empuje','<p>Deskripzio bat hemen<br/></p>',1,'2018-12-16 18:13:01','2018-12-16 18:13:01'),(16,'Extrusión Inversa','<p>Backward Extrusion, Taladrado, Punzonado<br/></p>',15,'2018-12-26 14:24:16','2018-12-26 14:24:16'),(17,'Recorte','<p>Arrastre  de material /Eliminación de material sobrante.</p>',15,'2018-12-26 14:59:25','2018-12-26 14:59:25'),(18,'Estación de paso','<p>Estación de paso<br/></p>',13,'2019-01-28 09:46:41','2019-01-28 09:46:41'),(19,'Taladrado','<p>taladrado</p>',13,'2019-02-11 09:49:59','2019-02-11 09:49:59'),(21,'Pruebas','<p>Operaciones de prueba</p>',1,'2019-03-28 19:55:58','2019-03-28 19:55:58');
/*!40000 ALTER TABLE `process_op_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_stage`
--

DROP TABLE IF EXISTS `process_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` text,
  `v_id` int(11) NOT NULL COMMENT 'version',
  `ord` int(4) NOT NULL DEFAULT '0' COMMENT 'order',
  `uid` int(11) NOT NULL COMMENT 'owner',
  `cmm_c` int(4) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `version` (`v_id`),
  KEY `user` (`uid`),
  CONSTRAINT `process_stage_ibfk_1` FOREIGN KEY (`v_id`) REFERENCES `process_version` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_stage_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=185 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_stage`
--

LOCK TABLES `process_stage` WRITE;
/*!40000 ALTER TABLE `process_stage` DISABLE KEYS */;
INSERT INTO `process_stage` VALUES (89,'<p>Etapa honen deskripzioa</p>',1,0,1,0,'2019-01-21 18:07:07','2019-01-21 18:07:07'),(90,NULL,1,1,1,0,'2019-01-21 18:07:43','2019-01-21 18:07:43'),(91,NULL,1,2,1,0,'2019-01-21 18:08:05','2019-01-21 18:08:05'),(92,NULL,1,3,1,0,'2019-01-21 18:08:20','2019-01-21 18:08:20'),(93,NULL,1,4,1,0,'2019-01-21 18:08:46','2019-01-21 18:08:46'),(94,NULL,1,5,1,0,'2019-01-21 18:08:57','2019-01-21 18:08:57'),(116,NULL,3,0,16,0,'2019-01-25 09:23:31','2019-01-25 09:23:31'),(117,'<p>Punteado</p>',3,1,16,0,'2019-01-25 09:38:29','2019-01-25 09:38:29'),(122,'<p>Extrusión del 53%</p>',3,2,16,0,'2019-01-25 09:48:42','2019-01-25 09:48:42'),(123,'<p>Escuadre</p>',3,3,16,0,'2019-01-25 09:52:09','2019-01-25 09:52:09'),(124,NULL,4,0,16,0,'2019-01-25 09:54:26','2019-01-25 09:54:26'),(125,'<p>Punteado</p>',4,1,16,0,'2019-01-25 09:54:26','2019-01-25 09:54:26'),(126,'<p>Extrusión del 53%</p>',4,2,16,0,'2019-01-25 09:54:26','2019-01-25 09:54:26'),(127,'<p>Escuadre</p>',4,3,16,0,'2019-01-25 09:54:26','2019-01-25 09:54:26'),(133,'<p>corte</p>',6,0,14,0,'2019-01-28 10:27:35','2019-01-28 10:27:35'),(134,'<p>Estación de paso</p>',6,1,14,0,'2019-01-28 10:38:21','2019-01-28 10:38:21'),(135,'<p>sizing</p>',6,2,14,0,'2019-01-28 11:10:00','2019-01-28 11:10:00'),(136,'<p>Estrusión en zona superior</p>',6,3,14,0,'2019-01-28 11:21:01','2019-01-28 11:21:01'),(137,'\n		',6,4,14,0,'2019-01-29 10:00:51','2019-01-29 10:00:51'),(149,'<p>corte</p>',7,0,14,0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(150,'<p>Estación de paso</p>',7,1,14,0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(151,'<p>sizing</p>',7,2,14,0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(152,'<p>Estrusión en zona superior</p>',7,3,14,0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(153,'\n		',7,4,14,0,'2019-01-30 11:39:27','2019-01-30 11:39:27'),(159,'<p>FORMACIÓN DE HEXAGONO+TREFILADO+PUNZONADO+ ESTAMPAR DIÁMETRO PREVIO MOLETEADO</p>',6,5,14,0,'2019-01-30 11:45:41','2019-01-30 11:45:41'),(160,'<p>corte</p>',8,0,13,0,'2019-02-08 12:08:47','2019-02-08 12:08:47'),(161,'<p>pasar material</p>',8,1,13,0,'2019-02-08 12:14:40','2019-02-08 12:14:40'),(162,'<p>recalacado</p>',8,2,13,0,'2019-02-08 12:19:00','2019-02-08 12:19:00'),(163,'<p>taladrado inferior + formar cono + extruir saliente superior y formación de entrada taladro superior</p>',8,3,13,0,'2019-02-11 09:54:59','2019-02-11 09:54:59'),(164,'<p>recalcado de valona + Chaflán de entrada no formado</p>',8,4,13,0,'2019-02-11 10:25:06','2019-02-11 10:25:06'),(165,'<p>Recorte del Códizo</p>',8,5,13,0,'2019-02-11 10:31:07','2019-02-11 10:31:07'),(166,'<p>recorte exterior</p>',8,6,13,0,'2019-02-12 07:07:32','2019-02-12 07:07:32'),(167,'<p>corte</p>',9,0,13,0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(168,'<p>pasar material</p>',9,1,13,0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(169,'<p>recalacado</p>',9,2,13,0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(170,'<p>taladrado inferior + formar cono + extruir saliente superior y formación de entrada taladro superior</p>',9,3,13,0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(171,'<p>recalcado de valona + Chaflán de entrada no formado</p>',9,4,13,0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(172,'<p>Recorte del Códizo</p>',9,5,13,0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(173,'<p>recorte exterior</p>',9,6,13,0,'2019-02-12 07:09:29','2019-02-12 07:09:29'),(178,NULL,11,0,16,0,'2019-03-09 05:47:14','2019-03-09 05:47:14'),(179,'<p>Preparación previa a la extrusión</p>',11,1,16,0,'2019-03-09 05:50:22','2019-03-09 05:50:22'),(184,NULL,13,0,1,0,'2019-03-28 20:17:57','2019-03-28 20:17:57');
/*!40000 ALTER TABLE `process_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_version`
--

DROP TABLE IF EXISTS `process_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `prc_id` int(11) NOT NULL,
  `mtl_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `descr` text,
  `cmm_c` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `process` (`prc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_version`
--

LOCK TABLES `process_version` WRITE;
/*!40000 ALTER TABLE `process_version` DISABLE KEYS */;
INSERT INTO `process_version` VALUES (1,'v.1',32,5,1,NULL,2,'2019-03-08 11:21:08','0000-00-00 00:00:00'),(3,'v.1',33,6,16,'<p>...</p>',0,'2019-03-08 11:33:17','0000-00-00 00:00:00'),(4,'v.2',33,6,16,NULL,0,'2019-03-08 11:33:17','0000-00-00 00:00:00'),(6,'v.1',34,6,14,NULL,0,'2019-03-08 11:41:29','0000-00-00 00:00:00'),(7,'v.2',34,6,14,NULL,0,'2019-03-08 11:41:29','0000-00-00 00:00:00'),(8,'v.1',35,6,13,NULL,0,'2019-03-08 11:54:39','0000-00-00 00:00:00'),(9,'v.2',35,6,13,NULL,0,'2019-03-08 11:54:39','0000-00-00 00:00:00'),(11,'Version 1',36,5,16,NULL,0,'2019-03-09 05:47:00','2019-03-09 05:47:00'),(13,'Version 1',38,6,1,NULL,0,'2019-03-28 20:17:51','2019-03-28 20:17:51');
/*!40000 ALTER TABLE `process_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `state` smallint(6) DEFAULT NULL,
  `roles` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Pamintxa','iturri.jon@gmail.com',NULL,'$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-27 17:40:09','0000-00-00 00:00:00'),(13,'JJOxemaiB','jjoxemaib@example.com',NULL,'$2y$14$WzYaePOiSukHEuAtfkasle6cPP4EGIELTRjA4KwaVAGWH7UUGTLp.',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-30 07:28:30','2018-11-30 07:28:30'),(14,'AITOR','diaz@imaltuna.com',NULL,'$2y$14$5XB/qM.PPOPFEtB/Cgz9uu04prFbvurOG.dSTjCEkyrzcxygz4Nmm',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-30 11:10:29','2018-11-30 11:10:29'),(15,'Unai Ziarsolo','unai@maltuna.eus',NULL,'$2y$14$UDAQji1qKcGa9xT4rqglYu5jUauFftnWvmdh.g40r1Sop4WK/YXZi',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-30 11:30:09','2018-11-30 11:30:09'),(16,'UnaiEcenarro','ucornes@ecenarro.com',NULL,'$2y$14$ABytkkPetNyLbgydbQ5/TOO5o7VJa9C83BX8m9ad/X9ZYB9r/7B7S',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:05:48','2018-12-17 16:05:48'),(17,'MariaAzpeitia','mazpeitia@ecenarro.com',NULL,'$2y$14$7n/2a876TJjzjvIu5qrhz.Hlc8/O0WfjWomh2dE3YRuphWzlZTz3C',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:07:07','2018-12-17 16:07:07'),(18,'Jon Agirre','jagirre@ecenarro.com',NULL,'$2y$14$MjGrviJbGArW91k6VxGzAepQhV.p4obk9SQVSc7OEBBjR4SyZ1Z3a',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:07:35','2018-12-17 16:07:35'),(19,'Patxi Molina','pmolina@ecenarro.com',NULL,'$2y$14$EcWGPnORV8/ZvPzM0FtjGeVLrQS0mLtF/Gqpl1DeDLmJKrqUTwMAq',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:08:03','2018-12-17 16:08:03'),(20,'Jon Arriaran','jarriaran@ecenarro.com',NULL,'$2y$14$jMRCkszHBdY.Ozz6g971pOy/jHOnwX6LmJs8tjPk8HhHlqyrn41ki',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:11:58','2018-12-17 16:11:58'),(21,'Alex Axkoeta','aaxkoeta@iurretalhi.eus',NULL,'$2y$14$8KHOJslbTULSTUSgAO81XecOZD2YDDbceYN.gH8t3GU/cr3BoCOxS',NULL,'a:1:{i:0;s:4:\"user\";}','2019-01-24 08:49:28','2019-01-24 08:49:28');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-29  8:22:33
