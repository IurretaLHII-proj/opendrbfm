-- MySQL dump 10.13  Distrib 5.5.60, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: ma_drbfm
-- ------------------------------------------------------
-- Server version	5.5.60-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action`
--

DROP TABLE IF EXISTS `action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) NOT NULL COMMENT 'source',
  `name` varchar(255) NOT NULL,
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action`
--

LOCK TABLES `action` WRITE;
/*!40000 ALTER TABLE `action` DISABLE KEYS */;
/*!40000 ALTER TABLE `action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) NOT NULL COMMENT 'source',
  `prt_id` int(11) DEFAULT NULL COMMENT 'parent',
  `body` text NOT NULL,
  `cmm_c` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(36) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent` (`prt_id`),
  KEY `source` (`src_id`),
  KEY `user` (`uid`),
  CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`prt_id`) REFERENCES `comment` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `phone` varchar(64) NOT NULL,
  `contact` varchar(64) NOT NULL,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `descr` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (4,1111,'Customer 1','customer1@example.eus','123456','Customer1 Name',1,'2019-01-21 19:02:16','2019-01-21 19:02:16','<p>Customer1 Description</p>');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int(6) NOT NULL,
  `descr` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `source` (`src_id`),
  KEY `user` (`uid`),
  CONSTRAINT `image_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
INSERT INTO `image` VALUES (11,1,NULL,'./public/img/php4BW8mT','image/png',16376,NULL,'2019-04-09 16:03:00','simulation'),(12,1,NULL,'./public/img/phpFcfbVH','image/png',10999,NULL,'2019-04-09 16:03:43','simulation'),(13,1,NULL,'./public/img/phpoowKyG','image/png',17456,NULL,'2019-04-09 16:04:44','simulation'),(14,1,NULL,'./public/img/phpzEud9m','image/png',17456,NULL,'2019-04-09 16:11:30','simulation'),(15,1,NULL,'./public/img/phpcPzVRq','image/png',13361,NULL,'2019-04-09 16:11:38','simulation'),(16,1,NULL,'./public/img/phpvu0tQA','image/png',10999,NULL,'2019-04-09 16:11:46','simulation'),(17,1,NULL,'./public/img/php4QRD3F','image/jpeg',3906,NULL,'2019-04-09 16:16:03','simulation'),(18,1,NULL,'./public/img/phpCubLq3','image/jpeg',3906,NULL,'2019-04-09 16:16:19','simulation'),(19,1,NULL,'./public/img/phpnJtDbR','image/jpeg',76639,NULL,'2019-04-09 16:16:22','simulation'),(20,1,NULL,'./public/img/phpEuuo5P','image/jpeg',116752,NULL,'2019-04-09 16:16:26','simulation'),(21,1,NULL,'./public/img/phpaAvSTx','image/jpeg',62610,NULL,'2019-04-09 16:47:09','simulation');
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `src_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `cmm_c` int(4) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(24) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `source` (`src_id`),
  KEY `user` (`uid`),
  CONSTRAINT `note_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note`
--

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;
/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process`
--

DROP TABLE IF EXISTS `process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `number` int(4) NOT NULL,
  `line` int(2) NOT NULL,
  `code` int(11) NOT NULL,
  `plant` varchar(64) NOT NULL,
  `machine` varchar(64) NOT NULL,
  `p_num` varchar(64) NOT NULL COMMENT 'piece number',
  `p_name` varchar(64) NOT NULL COMMENT 'piece name',
  `complex` varchar(4) NOT NULL DEFAULT 'AA',
  `ctm_id` int(11) NOT NULL COMMENT 'customer',
  `body` text,
  `uid` int(11) NOT NULL COMMENT 'owner',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user` (`uid`),
  KEY `customer` (`ctm_id`),
  CONSTRAINT `process_ibfk_1` FOREIGN KEY (`ctm_id`) REFERENCES `customer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process`
--

LOCK TABLES `process` WRITE;
/*!40000 ALTER TABLE `process` DISABLE KEYS */;
/*!40000 ALTER TABLE `process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_action`
--

DROP TABLE IF EXISTS `process_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `pcs_id` int(11) NOT NULL COMMENT 'process',
  `src_id` int(11) NOT NULL COMMENT 'source',
  `name` varchar(255) NOT NULL,
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `src-process` (`pcs_id`,`src_id`,`discr`),
  KEY `process` (`pcs_id`),
  KEY `source` (`src_id`),
  KEY `discr` (`discr`),
  KEY `user` (`uid`),
  CONSTRAINT `process_action_ibfk_1` FOREIGN KEY (`pcs_id`) REFERENCES `process` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_action_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_action`
--

LOCK TABLES `process_action` WRITE;
/*!40000 ALTER TABLE `process_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint`
--

DROP TABLE IF EXISTS `process_hint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stg_id` int(11) NOT NULL COMMENT 'stage',
  `type_id` int(11) DEFAULT NULL COMMENT 'error type',
  `uid` int(11) NOT NULL COMMENT 'owner',
  `prior` int(2) NOT NULL DEFAULT '1' COMMENT 'priority',
  `text` varchar(255) DEFAULT NULL,
  `who` varchar(255) DEFAULT NULL COMMENT 'who modelizes',
  `whn` timestamp NULL DEFAULT NULL COMMENT 'when modelizes',
  `eff` text COMMENT 'effect',
  `prev` text COMMENT 'prevention',
  `state` int(2) NOT NULL DEFAULT '0' COMMENT 'modelize state',
  `descr` text,
  `cmm_c` int(4) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `stg_id` (`stg_id`),
  KEY `user` (`uid`),
  KEY `error_type` (`type_id`),
  CONSTRAINT `process_hint_ibfk_1` FOREIGN KEY (`stg_id`) REFERENCES `process_stage` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_ibfk_2` FOREIGN KEY (`type_id`) REFERENCES `process_hint_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_ibfk_3` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint`
--

LOCK TABLES `process_hint` WRITE;
/*!40000 ALTER TABLE `process_hint` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_hint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_influence`
--

DROP TABLE IF EXISTS `process_hint_influence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_influence` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT 'user',
  `rsn_id` int(11) NOT NULL COMMENT 'reason',
  `cmm_c` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_influence`
--

LOCK TABLES `process_hint_influence` WRITE;
/*!40000 ALTER TABLE `process_hint_influence` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_hint_influence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_reason`
--

DROP TABLE IF EXISTS `process_hint_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_reason` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `hint_id` int(11) NOT NULL,
  `cmm_c` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `hint` (`hint_id`),
  KEY `user` (`uid`),
  CONSTRAINT `process_hint_reason_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_reason_ibfk_2` FOREIGN KEY (`hint_id`) REFERENCES `process_hint` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_reason`
--

LOCK TABLES `process_hint_reason` WRITE;
/*!40000 ALTER TABLE `process_hint_reason` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_hint_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_relation`
--

DROP TABLE IF EXISTS `process_hint_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_relation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) NOT NULL COMMENT 'reason source',
  `rel_id` int(11) NOT NULL COMMENT 'influence rel',
  `descr` text,
  `cmm_c` int(4) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user` (`uid`),
  KEY `source` (`src_id`),
  KEY `relation` (`rel_id`),
  CONSTRAINT `process_hint_relation_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_relation_ibfk_2` FOREIGN KEY (`src_id`) REFERENCES `process_hint_reason` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_relation_ibfk_3` FOREIGN KEY (`rel_id`) REFERENCES `process_hint_influence` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_relation`
--

LOCK TABLES `process_hint_relation` WRITE;
/*!40000 ALTER TABLE `process_hint_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_hint_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_simulation`
--

DROP TABLE IF EXISTS `process_hint_simulation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_simulation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) NOT NULL COMMENT 'influence',
  `state` int(2) NOT NULL DEFAULT '0',
  `who` text,
  `whn` text,
  `eff` text,
  `prev` text,
  `descr` text,
  `cmm_c` int(4) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user` (`uid`),
  KEY `source` (`src_id`),
  CONSTRAINT `process_hint_simulation_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_simulation_ibfk_2` FOREIGN KEY (`src_id`) REFERENCES `process_hint_influence` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_simulation`
--

LOCK TABLES `process_hint_simulation` WRITE;
/*!40000 ALTER TABLE `process_hint_simulation` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_hint_simulation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_type`
--

DROP TABLE IF EXISTS `process_hint_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `op_id` int(11) NOT NULL COMMENT 'operation',
  `prior` int(2) NOT NULL DEFAULT '0',
  `h_count` int(11) NOT NULL DEFAULT '0' COMMENT 'error count',
  `title` varchar(255) NOT NULL,
  `descr` text,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `operation` (`op_id`),
  CONSTRAINT `process_hint_type_ibfk_1` FOREIGN KEY (`op_id`) REFERENCES `process_op` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_type`
--

LOCK TABLES `process_hint_type` WRITE;
/*!40000 ALTER TABLE `process_hint_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_hint_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_material`
--

DROP TABLE IF EXISTS `process_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `prior` int(2) NOT NULL DEFAULT '0',
  `descr` text,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_material`
--

LOCK TABLES `process_material` WRITE;
/*!40000 ALTER TABLE `process_material` DISABLE KEYS */;
INSERT INTO `process_material` VALUES (5,'C8C',1,'<p>Materialaren deskripzio bat</p>',1,'2019-01-21 19:02:35','2019-01-21 19:02:35'),(6,'42CrMo4',4,NULL,16,'2019-01-25 10:21:26','2019-01-25 10:21:26');
/*!40000 ALTER TABLE `process_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op`
--

DROP TABLE IF EXISTS `process_op`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `descr` text,
  `type_id` int(11) NOT NULL COMMENT 'operation type',
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `operation_type` (`type_id`),
  KEY `user` (`uid`),
  CONSTRAINT `process_op_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `process_op_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_op_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op`
--

LOCK TABLES `process_op` WRITE;
/*!40000 ALTER TABLE `process_op` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_op` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op_rel`
--

DROP TABLE IF EXISTS `process_op_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op_rel` (
  `parent_id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL,
  UNIQUE KEY `rel` (`parent_id`,`child_id`),
  KEY `child_id` (`child_id`),
  CONSTRAINT `process_op_rel_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `process_op` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_op_rel_ibfk_2` FOREIGN KEY (`child_id`) REFERENCES `process_op` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op_rel`
--

LOCK TABLES `process_op_rel` WRITE;
/*!40000 ALTER TABLE `process_op_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_op_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op_stg_rel`
--

DROP TABLE IF EXISTS `process_op_stg_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op_stg_rel` (
  `op_id` int(11) NOT NULL,
  `stg_id` int(11) NOT NULL,
  UNIQUE KEY `op_stg_rel` (`op_id`,`stg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op_stg_rel`
--

LOCK TABLES `process_op_stg_rel` WRITE;
/*!40000 ALTER TABLE `process_op_stg_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_op_stg_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op_type`
--

DROP TABLE IF EXISTS `process_op_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `descr` text,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user` (`uid`),
  CONSTRAINT `process_op_type_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op_type`
--

LOCK TABLES `process_op_type` WRITE;
/*!40000 ALTER TABLE `process_op_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_op_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_stage`
--

DROP TABLE IF EXISTS `process_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` text,
  `v_id` int(11) NOT NULL COMMENT 'version',
  `ord` int(4) NOT NULL DEFAULT '0' COMMENT 'order',
  `uid` int(11) NOT NULL COMMENT 'owner',
  `cmm_c` int(4) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `version` (`v_id`),
  KEY `user` (`uid`),
  CONSTRAINT `process_stage_ibfk_1` FOREIGN KEY (`v_id`) REFERENCES `process_version` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_stage_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_stage`
--

LOCK TABLES `process_stage` WRITE;
/*!40000 ALTER TABLE `process_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_version`
--

DROP TABLE IF EXISTS `process_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `prc_id` int(11) NOT NULL,
  `mtl_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `state` int(4) NOT NULL DEFAULT '0',
  `descr` text,
  `cmm_c` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `process` (`prc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_version`
--

LOCK TABLES `process_version` WRITE;
/*!40000 ALTER TABLE `process_version` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `state` smallint(6) DEFAULT NULL,
  `roles` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Pamintxa','iturri.jon@gmail.com',NULL,'$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-27 17:40:09','0000-00-00 00:00:00'),(13,'JJOxemaiB','jjoxemaib@example.com',NULL,'$2y$14$WzYaePOiSukHEuAtfkasle6cPP4EGIELTRjA4KwaVAGWH7UUGTLp.',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-30 07:28:30','2018-11-30 07:28:30'),(14,'AITOR','diaz@imaltuna.com',NULL,'$2y$14$5XB/qM.PPOPFEtB/Cgz9uu04prFbvurOG.dSTjCEkyrzcxygz4Nmm',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-30 11:10:29','2018-11-30 11:10:29'),(15,'Unai Ziarsolo','unai@maltuna.eus',NULL,'$2y$14$UDAQji1qKcGa9xT4rqglYu5jUauFftnWvmdh.g40r1Sop4WK/YXZi',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-30 11:30:09','2018-11-30 11:30:09'),(16,'UnaiEcenarro','ucornes@ecenarro.com',NULL,'$2y$14$ABytkkPetNyLbgydbQ5/TOO5o7VJa9C83BX8m9ad/X9ZYB9r/7B7S',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:05:48','2018-12-17 16:05:48'),(17,'MariaAzpeitia','mazpeitia@ecenarro.com',NULL,'$2y$14$7n/2a876TJjzjvIu5qrhz.Hlc8/O0WfjWomh2dE3YRuphWzlZTz3C',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:07:07','2018-12-17 16:07:07'),(18,'Jon Agirre','jagirre@ecenarro.com',NULL,'$2y$14$MjGrviJbGArW91k6VxGzAepQhV.p4obk9SQVSc7OEBBjR4SyZ1Z3a',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:07:35','2018-12-17 16:07:35'),(19,'Patxi Molina','pmolina@ecenarro.com',NULL,'$2y$14$EcWGPnORV8/ZvPzM0FtjGeVLrQS0mLtF/Gqpl1DeDLmJKrqUTwMAq',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:08:03','2018-12-17 16:08:03'),(20,'Jon Arriaran','jarriaran@ecenarro.com',NULL,'$2y$14$jMRCkszHBdY.Ozz6g971pOy/jHOnwX6LmJs8tjPk8HhHlqyrn41ki',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:11:58','2018-12-17 16:11:58'),(21,'Alex Axkoeta','aaxkoeta@iurretalhi.eus',NULL,'$2y$14$8KHOJslbTULSTUSgAO81XecOZD2YDDbceYN.gH8t3GU/cr3BoCOxS',NULL,'a:1:{i:0;s:4:\"user\";}','2019-01-24 08:49:28','2019-01-24 08:49:28');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-10 10:42:07
