-- MySQL dump 10.13  Distrib 5.5.60, for debian-linux-gnu (i686)
--
-- Host: localhost    Database: ma_drbfm
-- ------------------------------------------------------
-- Server version	5.5.60-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `action`
--

DROP TABLE IF EXISTS `action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) NOT NULL COMMENT 'source',
  `name` varchar(255) NOT NULL,
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action`
--

LOCK TABLES `action` WRITE;
/*!40000 ALTER TABLE `action` DISABLE KEYS */;
INSERT INTO `action` VALUES (1,1,164,'create','a:0:{}','2019-01-24 08:27:11','op'),(2,1,97,'update','a:0:{}','2019-01-24 08:33:13','op'),(3,1,97,'update','a:0:{}','2019-01-24 08:33:21','op'),(4,1,95,'update','a:0:{}','2019-02-21 17:29:12','op'),(5,1,129,'update','a:0:{}','2019-03-02 19:27:11','op'),(6,1,164,'create','a:0:{}','2019-03-02 19:29:22','op'),(7,1,164,'update','a:0:{}','2019-03-02 19:30:55','op'),(8,1,164,'update','a:0:{}','2019-03-02 19:31:02','op'),(9,1,164,'update','a:0:{}','2019-03-02 19:31:07','op'),(10,1,99,'update','a:1:{s:6:\"insert\";a:2:{i:0;a:7:{s:2:\"id\";i:98;s:4:\"name\";s:10:\"En ángulo\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:55:25\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:55:25\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:7:{s:2:\"id\";i:97;s:4:\"name\";s:15:\"Severa (50-70%)\";s:5:\"owner\";r:6;s:11:\"description\";s:248:\"<ul><li>No cilíndricas. (estrias, ranuras, cuadrados etc)</li><li>Con ángulo en vez de radio</li><li>Grandes longitudes de extrusión (L&gt;3d??)</li><li>Con estacion previa de preparación</li><li>Distribuida entre buterola/matriz<br/></li></ul>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:54:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:54:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-03 11:38:17','op'),(11,1,96,'update','a:0:{}','2019-03-03 12:16:29','op'),(12,1,109,'update','a:1:{s:6:\"insert\";a:2:{i:0;a:7:{s:2:\"id\";i:96;s:4:\"name\";s:8:\"En radio\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";s:10:\"<p>jjj</p>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:53:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:53:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:7:{s:2:\"id\";i:111;s:4:\"name\";s:9:\"Punzonado\";s:5:\"owner\";r:6;s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:04:36\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:04:36\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-03 12:16:38','op'),(13,1,109,'update','a:0:{}','2019-03-03 12:16:49','op'),(14,1,109,'update','a:0:{}','2019-03-03 12:16:59','op'),(16,1,166,'create','a:1:{s:6:\"insert\";a:2:{i:0;a:7:{s:2:\"id\";i:95;s:4:\"name\";s:8:\"Standard\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";s:18:\"<p>bla bla bla</p>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:51:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:51:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:7:{s:2:\"id\";i:108;s:4:\"name\";s:21:\"Grandes deformaciones\";s:5:\"owner\";r:6;s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:03:41\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:03:41\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-03 12:17:59','op'),(17,1,167,'create','a:1:{s:6:\"insert\";a:2:{i:0;a:7:{s:2:\"id\";i:95;s:4:\"name\";s:8:\"Standard\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";s:18:\"<p>bla bla bla</p>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:51:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:51:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:7:{s:2:\"id\";i:166;s:4:\"name\";s:32:\"Standard + Grandes deformaciones\";s:5:\"owner\";r:6;s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-03 13:17:59\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-03 13:17:59\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-03 12:18:21','op'),(19,1,131,'update','a:1:{s:6:\"insert\";a:1:{i:0;a:7:{s:2:\"id\";i:97;s:4:\"name\";s:15:\"Severa (50-70%)\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";s:248:\"<ul><li>No cilíndricas. (estrias, ranuras, cuadrados etc)</li><li>Con ángulo en vez de radio</li><li>Grandes longitudes de extrusión (L&gt;3d??)</li><li>Con estacion previa de preparación</li><li>Distribuida entre buterola/matriz<br/></li></ul>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:54:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:54:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-03 12:37:29','op'),(20,1,131,'update','a:1:{s:6:\"insert\";a:2:{i:0;a:7:{s:2:\"id\";i:97;s:4:\"name\";s:15:\"Severa (50-70%)\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";s:248:\"<ul><li>No cilíndricas. (estrias, ranuras, cuadrados etc)</li><li>Con ángulo en vez de radio</li><li>Grandes longitudes de extrusión (L&gt;3d??)</li><li>Con estacion previa de preparación</li><li>Distribuida entre buterola/matriz<br/></li></ul>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:54:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:54:54\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:7:{s:2:\"id\";i:98;s:4:\"name\";s:10:\"En ángulo\";s:5:\"owner\";r:6;s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:55:25\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 18:55:25\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-03 12:37:53','op'),(21,1,109,'update','a:0:{}','2019-03-03 12:45:23','op'),(22,1,109,'update','a:0:{}','2019-03-03 12:46:32','op'),(23,1,167,'create','a:0:{}','2019-03-03 17:46:47','op'),(24,1,168,'create','a:0:{}','2019-03-03 17:52:08','op'),(25,1,169,'create','a:1:{s:6:\"insert\";a:2:{i:0;a:7:{s:2:\"id\";i:104;s:4:\"name\";s:7:\"Abierto\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";s:138:\"<p>Aumentar la sección de una parte del material sin sujetar el material dentro de los utillajes. Límite de recalcado libre r=2<br/></p>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:01:28\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:01:28\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:7:{s:2:\"id\";i:105;s:4:\"name\";s:7:\"Cerrado\";s:5:\"owner\";r:6;s:11:\"description\";s:135:\"<p>Aumentar la seccion de una parte del material sujetando el material dentro de los utillajes. Límite de recalcado libre r=2<br/></p>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:01:43\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-16 19:01:43\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-05 13:19:40','op'),(26,1,170,'create','a:0:{}','2019-03-05 15:30:10','op'),(27,1,171,'create','a:1:{s:6:\"insert\";a:2:{i:0;a:7:{s:2:\"id\";i:170;s:4:\"name\";s:6:\"Nonono\";s:5:\"owner\";O:14:\"MA\\Entity\\User\":9:{s:8:\"\0*\0roles\";a:1:{i:0;s:4:\"user\";}s:10:\"\0*\0created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-11-27 18:40:09\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:10:\"\0*\0updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:20:\"-0001-11-30 00:00:00\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:5:\"\0*\0id\";i:1;s:11:\"\0*\0username\";s:8:\"Pamintxa\";s:8:\"\0*\0email\";s:20:\"iturri.jon@gmail.com\";s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";s:60:\"$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC\";s:8:\"\0*\0state\";N;}s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-05 16:30:10\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-05 16:30:10\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:7:{s:2:\"id\";i:168;s:4:\"name\";s:7:\"Nwe One\";s:5:\"owner\";r:6;s:11:\"description\";N;s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-03 18:52:08\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2019-03-03 18:52:08\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-05 15:47:10','op'),(28,1,172,'create','a:1:{s:6:\"insert\";a:2:{i:0;a:7:{s:2:\"id\";i:161;s:4:\"name\";s:7:\"Recorte\";s:5:\"owner\";O:45:\"DoctrineORMModule\\Proxy\\__CG__\\MA\\Entity\\User\":10:{s:17:\"__isInitialized__\";b:0;s:8:\"\0*\0roles\";a:0:{}s:10:\"\0*\0created\";N;s:10:\"\0*\0updated\";N;s:5:\"\0*\0id\";i:15;s:11:\"\0*\0username\";N;s:8:\"\0*\0email\";N;s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";N;s:8:\"\0*\0state\";N;}s:11:\"description\";s:49:\"<p>Eliminación del sobrante de material<br/></p>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-26 17:00:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-26 17:00:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:7:{s:2:\"id\";i:162;s:4:\"name\";s:7:\"Parcial\";s:5:\"owner\";r:6;s:11:\"description\";s:89:\"<p>Operación previa al recortado total donde se recorta material sin hacerlo pasante</p>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-26 17:01:44\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-26 17:01:44\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-05 15:50:59','op'),(29,1,173,'create','a:1:{s:6:\"insert\";a:2:{i:0;a:8:{s:2:\"id\";i:161;s:4:\"name\";s:7:\"Recorte\";s:8:\"longName\";s:16:\"Recorte. Recorte\";s:5:\"owner\";O:45:\"DoctrineORMModule\\Proxy\\__CG__\\MA\\Entity\\User\":10:{s:17:\"__isInitialized__\";b:0;s:8:\"\0*\0roles\";a:0:{}s:10:\"\0*\0created\";N;s:10:\"\0*\0updated\";N;s:5:\"\0*\0id\";i:15;s:11:\"\0*\0username\";N;s:8:\"\0*\0email\";N;s:14:\"\0*\0displayName\";N;s:11:\"\0*\0password\";N;s:8:\"\0*\0state\";N;}s:11:\"description\";s:49:\"<p>Eliminación del sobrante de material<br/></p>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-26 17:00:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-26 17:00:24\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}i:1;a:8:{s:2:\"id\";i:162;s:4:\"name\";s:7:\"Parcial\";s:8:\"longName\";s:16:\"Recorte. Parcial\";s:5:\"owner\";r:7;s:11:\"description\";s:89:\"<p>Operación previa al recortado total donde se recorta material sin hacerlo pasante</p>\";s:8:\"children\";O:17:\"ZF\\Hal\\Collection\":15:{s:13:\"\0*\0attributes\";a:0:{}s:13:\"\0*\0collection\";O:33:\"Doctrine\\ORM\\PersistentCollection\":2:{s:13:\"\0*\0collection\";O:43:\"Doctrine\\Common\\Collections\\ArrayCollection\":1:{s:53:\"\0Doctrine\\Common\\Collections\\ArrayCollection\0elements\";a:0:{}}s:14:\"\0*\0initialized\";b:0;}s:17:\"\0*\0collectionName\";s:5:\"items\";s:18:\"\0*\0collectionRoute\";N;s:25:\"\0*\0collectionRouteOptions\";a:0:{}s:24:\"\0*\0collectionRouteParams\";a:0:{}s:23:\"\0*\0entityIdentifierName\";s:2:\"id\";s:22:\"\0*\0routeIdentifierName\";s:2:\"id\";s:7:\"\0*\0page\";i:1;s:11:\"\0*\0pageSize\";i:30;s:14:\"\0*\0entityLinks\";N;s:14:\"\0*\0entityRoute\";N;s:21:\"\0*\0entityRouteOptions\";a:0:{}s:20:\"\0*\0entityRouteParams\";a:0:{}s:8:\"\0*\0links\";N;}s:7:\"updated\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-26 17:01:44\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}s:7:\"created\";O:8:\"DateTime\":3:{s:4:\"date\";s:19:\"2018-12-26 17:01:44\";s:13:\"timezone_type\";i:3;s:8:\"timezone\";s:13:\"Europe/Berlin\";}}}}','2019-03-06 17:16:22','op'),(30,1,174,'create','a:0:{}','2019-03-06 18:23:54','op');
/*!40000 ALTER TABLE `action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `src_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `body` text NOT NULL,
  `prt_id` int(11) DEFAULT NULL,
  `cmm_c` int(11) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(24) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `source` (`src_id`),
  KEY `user` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (38,26,1,'<p>bah</p>',NULL,0,'2019-03-06 16:04:06','simulation'),(39,29,1,'<p>aaa</p>',NULL,1,'2019-03-06 16:20:24','stage'),(40,29,1,'ssss....h',39,0,'2019-03-06 16:20:31','stage'),(41,34,1,'<p>.....</p>',NULL,0,'2019-03-06 17:43:26','stage'),(42,26,1,'<p>.....</p>',NULL,0,'2019-03-06 17:55:01','simulation'),(43,11,1,'<p>a</p>',NULL,3,'2019-03-06 18:34:03','version'),(44,11,1,'<p>b</p>',NULL,0,'2019-03-06 18:34:08','version'),(45,11,1,'<p>c</p>',NULL,0,'2019-03-06 18:34:10','version'),(46,11,1,'<p>d</p>',NULL,0,'2019-03-06 18:34:19','version'),(47,11,1,'a',43,0,'2019-03-06 18:34:33','version'),(48,11,1,'b',43,0,'2019-03-06 18:34:35','version'),(49,11,1,'c',43,0,'2019-03-06 18:34:38','version'),(50,11,1,'<p>e</p>',NULL,0,'2019-03-06 18:37:33','version'),(51,11,1,'<p>f</p>',NULL,0,'2019-03-06 18:37:35','version'),(52,11,1,'<p>g</p>',NULL,0,'2019-03-06 18:37:37','version'),(53,11,1,'<p>h</p>',NULL,0,'2019-03-06 18:41:07','version'),(54,11,1,'<p>i</p>',NULL,6,'2019-03-06 18:41:12','version'),(55,11,1,'j',54,0,'2019-03-06 18:41:25','version'),(56,11,1,'k',54,0,'2019-03-06 18:41:29','version'),(57,11,1,'l',54,0,'2019-03-06 18:41:31','version'),(58,11,1,'m',54,0,'2019-03-06 18:41:36','version'),(59,11,1,'jarl',54,1,'2019-03-06 18:42:47','version'),(60,11,1,'idiot',59,0,'2019-03-06 18:42:55','version'),(61,47,1,'<p>....</p>',NULL,0,'2019-03-06 18:55:50','stage'),(62,11,1,'ñ',54,0,'2019-03-07 07:37:57','version');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `phone` varchar(64) NOT NULL,
  `contact` varchar(64) NOT NULL,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `descr` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,1111,'Customer 1','customer1@example.eus','111','Customer 1 Name',1,'2019-01-22 17:12:52','2019-01-22 17:12:52','<p>Customer 1 Desc</p>'),(2,2222,'Customer 2','2222@example.com','223232','Name2',1,'2019-02-28 16:12:37','2019-02-28 16:12:37',NULL);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `src_id` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int(6) NOT NULL,
  `descr` varchar(255) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
INSERT INTO `image` VALUES (4,1,NULL,'./public/img/phpvPZEuO','image/png',3994,NULL,'2019-02-19 19:40:24'),(6,1,NULL,'./public/img/php8sa1nn','image/jpeg',116752,NULL,'2019-03-06 10:35:24'),(7,1,NULL,'./public/img/phpLn13MJ','image/jpeg',3906,NULL,'2019-03-06 10:37:07'),(8,1,NULL,'./public/img/phpTBHJ0j','image/jpeg',3906,NULL,'2019-03-06 10:38:09'),(9,1,NULL,'./public/img/phpfHb9gM','image/jpeg',76639,NULL,'2019-03-06 10:38:20'),(10,1,NULL,'./public/img/phpQItsYo','image/jpeg',116752,NULL,'2019-03-06 10:38:58'),(27,1,NULL,'./public/img/phpEDYgXD','image/png',13361,NULL,'2019-03-06 11:30:04'),(34,1,29,'./public/img/phpR2wTLL','image/png',3994,NULL,'2019-03-06 16:03:44'),(38,1,34,'./public/img/phpR2wTLL','image/png',3994,NULL,'2019-03-06 17:24:33'),(42,1,NULL,'./public/img/phpTIltj3','image/jpeg',69991,NULL,'2019-03-06 17:58:20'),(43,1,NULL,'./public/img/phpAxoT0P','image/jpeg',3906,NULL,'2019-03-06 17:58:38'),(44,1,40,'./public/img/php3RDqOC','image/png',7450,NULL,'2019-03-06 17:59:21'),(50,1,47,'./public/img/phpR2wTLL','image/png',3994,NULL,'2019-03-06 18:54:50');
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `src_id` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `cmm_c` int(11) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(24) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `simulation` (`src_id`),
  KEY `user` (`uid`),
  CONSTRAINT `note_ibfk_1` FOREIGN KEY (`src_id`) REFERENCES `process_hint_simulation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note`
--

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;
INSERT INTO `note` VALUES (12,'You could declare an abstract getter instead',NULL,NULL,0,'2019-02-19 18:30:55','hint-suggestion'),(31,'Azzz....',NULL,NULL,0,'2019-02-22 15:52:41','hint-suggestion'),(100,'Aliquam mollis massa eu tincidunt pretium.',26,1,0,'2019-03-06 16:03:44','hint-influence'),(101,'Aliquam mollis massa eu tincidunt pretium.',26,1,0,'2019-03-06 16:03:44','hint-influence'),(108,'Aliquam mollis massa eu tincidunt pretium.',29,1,0,'2019-03-06 17:24:33','hint-influence'),(118,'Aliquam eros nisi, sagittis vel faucibus vel, finibus ac lacus. Sed sed blandit lectus. Cras et mi ac felis cursus varius a vitae lectus',29,1,0,'2019-03-06 18:25:00','hint-suggestion'),(119,'Sed sed blandit lectus. Cras et mi ac felis cursus varius a vitae lectus',29,1,0,'2019-03-06 18:25:09','hint-reason'),(120,'Aliquam eros nisi, sagittis vel faucibus vel, finibus ac lacus',29,1,0,'2019-03-06 18:25:21','hint-influence'),(121,'Sed sed blandit lectus',29,1,0,'2019-03-06 18:25:41','hint-suggestion'),(131,'Sed sed blandit lectus. Cras et mi ac felis cursus varius a vitae lectus',37,1,0,'2019-03-06 18:54:50','hint-reason'),(132,'Aliquam eros nisi, sagittis vel faucibus vel, finibus ac lacus. Sed sed blandit lectus. Cras et mi ac felis cursus varius a vitae lectus',37,1,0,'2019-03-06 18:54:50','hint-suggestion'),(133,'Sed sed blandit lectus',37,1,0,'2019-03-06 18:54:50','hint-suggestion'),(134,'Aliquam mollis massa eu tincidunt pretium.',37,1,0,'2019-03-06 18:54:50','hint-influence'),(135,'Aliquam eros nisi, sagittis vel faucibus vel, finibus ac lacus',37,1,0,'2019-03-06 18:54:50','hint-influence');
/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process`
--

DROP TABLE IF EXISTS `process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `number` int(4) NOT NULL,
  `line` int(2) NOT NULL,
  `code` int(11) NOT NULL,
  `plant` varchar(64) NOT NULL,
  `machine` varchar(64) NOT NULL,
  `p_num` varchar(64) NOT NULL COMMENT 'piece number',
  `p_name` varchar(64) NOT NULL COMMENT 'piece name',
  `complex` varchar(4) NOT NULL DEFAULT 'AA',
  `ctm_id` int(11) NOT NULL COMMENT 'customer',
  `body` text,
  `uid` int(11) NOT NULL COMMENT 'owner',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user` (`uid`),
  KEY `customer` (`ctm_id`),
  CONSTRAINT `process_ibfk_2` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_ibfk_1` FOREIGN KEY (`ctm_id`) REFERENCES `customer` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process`
--

LOCK TABLES `process` WRITE;
/*!40000 ALTER TABLE `process` DISABLE KEYS */;
INSERT INTO `process` VALUES (1,'Confección de informes',1,11,1111,'USA','11efd','iuui','iuui','A',1,'<p></p><p style=\"font-size: 16px;\">El método <code style=\"background-color: rgba(220, 220, 220, 0.5);\"><strong>find()</strong></code> devuelve el <strong>valor</strong> del <strong>primer elemento</strong> del array que cumple la función de prueba proporcionada. En cualquier otro caso se devuelve <a href=\"https://developer.mozilla.org/es/docs/Web/JavaScript/Referencia/Objetos_globales/undefined\" title=\"La propiedad global undefined representa el valor primitivo undefined. Es uno de los valores primitivos de JavaScript.\"><code style=\"background-color: rgba(220, 220, 220, 0.5);\">undefined</code></a>.</p><p></p>',1,'2019-01-22 17:13:38','2019-01-22 17:13:38');
/*!40000 ALTER TABLE `process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_action`
--

DROP TABLE IF EXISTS `process_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_action` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `pcs_id` int(11) NOT NULL COMMENT 'process',
  `src_id` int(11) NOT NULL COMMENT 'source',
  `name` varchar(255) NOT NULL,
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `discr` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `src-process` (`pcs_id`,`src_id`,`discr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_action`
--

LOCK TABLES `process_action` WRITE;
/*!40000 ALTER TABLE `process_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint`
--

DROP TABLE IF EXISTS `process_hint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stg_id` int(11) NOT NULL COMMENT 'stage',
  `type_id` int(11) DEFAULT NULL COMMENT 'error type',
  `uid` int(11) NOT NULL COMMENT 'owner',
  `prior` int(2) NOT NULL DEFAULT '1',
  `text` varchar(255) DEFAULT NULL,
  `who` varchar(255) DEFAULT NULL COMMENT 'who modelizes',
  `whn` timestamp NULL DEFAULT NULL COMMENT 'when modelizes',
  `eff` text COMMENT 'effect',
  `prev` text COMMENT 'prevention',
  `state` int(2) NOT NULL DEFAULT '0' COMMENT 'modelize state',
  `descr` text,
  `cmm_c` int(11) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `stg_id` (`stg_id`),
  KEY `type` (`type_id`),
  KEY `user` (`uid`),
  CONSTRAINT `process_hint_ibfk_3` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_ibfk_1` FOREIGN KEY (`stg_id`) REFERENCES `process_stage` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_ibfk_2` FOREIGN KEY (`type_id`) REFERENCES `process_hint_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint`
--

LOCK TABLES `process_hint` WRITE;
/*!40000 ALTER TABLE `process_hint` DISABLE KEYS */;
INSERT INTO `process_hint` VALUES (21,29,14,1,-2,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-03-06 16:03:44','2019-03-06 16:03:44'),(24,34,14,1,7,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-03-06 17:24:33','2019-03-06 17:24:33'),(31,47,13,1,-7,NULL,NULL,NULL,NULL,NULL,0,NULL,0,'2019-03-06 18:54:50','2019-03-06 18:54:50');
/*!40000 ALTER TABLE `process_hint` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_rel`
--

DROP TABLE IF EXISTS `process_hint_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_rel` (
  `parent_id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL,
  UNIQUE KEY `rel` (`parent_id`,`child_id`),
  KEY `child_id` (`child_id`),
  CONSTRAINT `process_hint_rel_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `process_hint` (`id`),
  CONSTRAINT `process_hint_rel_ibfk_2` FOREIGN KEY (`child_id`) REFERENCES `process_hint` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_rel`
--

LOCK TABLES `process_hint_rel` WRITE;
/*!40000 ALTER TABLE `process_hint_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_hint_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_simulation`
--

DROP TABLE IF EXISTS `process_hint_simulation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_simulation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `hint_id` int(11) NOT NULL COMMENT 'error',
  `state` int(2) NOT NULL DEFAULT '0',
  `who` text,
  `whn` text,
  `eff` text,
  `prev` text,
  `descr` text,
  `cmm_c` int(11) NOT NULL DEFAULT '0' COMMENT 'comment count',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `user` (`uid`),
  KEY `error` (`hint_id`),
  CONSTRAINT `process_hint_simulation_ibfk_2` FOREIGN KEY (`hint_id`) REFERENCES `process_hint` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_hint_simulation_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_simulation`
--

LOCK TABLES `process_hint_simulation` WRITE;
/*!40000 ALTER TABLE `process_hint_simulation` DISABLE KEYS */;
INSERT INTO `process_hint_simulation` VALUES (26,1,21,1,'Txetxu','2019-03-20 00:00:00','<p>Sed sed blandit lectus. Cras et mi ac felis cursus varius a vitae lectus.<br/></p>','<p> Nullam pharetra augue id arcu faucibus, sed suscipit erat feugiat<br/></p>',NULL,2,'2019-03-06 16:03:44','2019-03-06 16:03:44'),(29,1,24,1,'Txetxu','2019-03-20 00:00:00','<p>Sed sed blandit lectus. Cras et mi ac felis cursus varius a vitae lectus.<br/></p>','<p> Nullam pharetra augue id arcu faucibus, sed suscipit erat feugiat<br/></p>',NULL,0,'2019-03-06 17:24:33','2019-03-06 17:24:33'),(37,1,31,1,'Txetxu','2019-03-20 00:00:00','<p>Sed sed blandit lectus. Cras et mi ac felis cursus varius a vitae lectus.<br/></p>','<p> Nullam pharetra augue id arcu faucibus, sed suscipit erat feugiat<br/></p>',NULL,0,'2019-03-06 18:54:50','2019-03-06 18:54:50');
/*!40000 ALTER TABLE `process_hint_simulation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_hint_type`
--

DROP TABLE IF EXISTS `process_hint_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_hint_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `op_id` int(11) NOT NULL COMMENT 'operation',
  `prior` int(2) NOT NULL DEFAULT '0',
  `h_count` int(11) NOT NULL DEFAULT '0' COMMENT 'error count',
  `title` varchar(255) NOT NULL,
  `descr` text,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `operation` (`op_id`),
  CONSTRAINT `process_hint_type_ibfk_1` FOREIGN KEY (`op_id`) REFERENCES `process_op` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_hint_type`
--

LOCK TABLES `process_hint_type` WRITE;
/*!40000 ALTER TABLE `process_hint_type` DISABLE KEYS */;
INSERT INTO `process_hint_type` VALUES (1,161,1,4,'Recorte defectuoso',NULL,1,'2019-01-22 17:14:27','2019-01-22 17:14:27'),(2,95,2,6,'Dobladete','I need to check if a persisted entity has changed and needs to be updated on the database. What I made',1,'2019-01-22 17:14:51','2019-01-22 17:14:51'),(3,97,2,0,'An error',NULL,1,'2019-01-24 08:33:43','2019-01-24 08:33:43'),(4,95,3,1,'Ez dugu trukerik',NULL,1,'2019-02-11 16:16:31','2019-02-11 16:16:31'),(5,95,-1,1,'Invent',NULL,1,'2019-02-25 15:30:38','2019-02-25 15:30:38'),(6,95,2,0,'Berriaaaa','MMMmmmm...',1,'2019-03-02 18:01:01','2019-03-02 18:01:01'),(7,95,1,0,'sss!!','sssss!!!!',1,'2019-03-02 18:03:07','2019-03-02 18:03:07'),(8,95,1,0,'aaaa','sss',1,'2019-03-02 18:06:59','2019-03-02 18:06:59'),(9,95,2,0,'Finalllll',NULL,1,'2019-03-02 18:07:27','2019-03-02 18:07:27'),(10,95,3,0,'How?','Lalala',1,'2019-03-02 18:14:42','2019-03-02 18:14:42'),(11,95,0,0,'Yeah','aaaaa',1,'2019-03-03 12:39:42','2019-03-03 12:39:42'),(12,108,0,0,'Yeaaaaah',NULL,1,'2019-03-03 12:40:00','2019-03-03 12:40:00'),(13,168,0,1,'Ha!',NULL,1,'2019-03-05 15:57:50','2019-03-05 15:57:50'),(14,167,0,2,'Ixo eta conforme',NULL,1,'2019-03-06 11:21:38','2019-03-06 11:21:38'),(15,167,0,0,'Ñ~~ñ',NULL,1,'2019-03-06 18:29:56','2019-03-06 18:29:56');
/*!40000 ALTER TABLE `process_hint_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_material`
--

DROP TABLE IF EXISTS `process_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `prior` int(2) NOT NULL DEFAULT '0',
  `descr` text,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_material`
--

LOCK TABLES `process_material` WRITE;
/*!40000 ALTER TABLE `process_material` DISABLE KEYS */;
INSERT INTO `process_material` VALUES (1,'C8C',-1,NULL,1,'2019-01-22 17:13:01','2019-01-22 17:13:01');
/*!40000 ALTER TABLE `process_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op`
--

DROP TABLE IF EXISTS `process_op`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `descr` text,
  `type_id` int(11) NOT NULL COMMENT 'operation type',
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `type` (`type_id`),
  CONSTRAINT `process_op_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `process_op_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=175 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op`
--

LOCK TABLES `process_op` WRITE;
/*!40000 ALTER TABLE `process_op` DISABLE KEYS */;
INSERT INTO `process_op` VALUES (95,'Standard','<p>bla bla bla</p>',8,1,'2018-12-16 17:51:24','2018-12-16 17:51:24'),(96,'En radio','<p>jjj</p>',9,1,'2018-12-16 17:53:54','2018-12-16 17:53:54'),(97,'Severa (50-70%)','<ul><li>No cilíndricas. (estrias, ranuras, cuadrados etc)</li><li>Con ángulo en vez de radio</li><li>Grandes longitudes de extrusión (L&gt;3d??)</li><li>Con estacion previa de preparación</li><li>Distribuida entre buterola/matriz<br/></li></ul>',10,1,'2018-12-16 17:54:54','2018-12-16 17:54:54'),(98,'En ángulo',NULL,10,1,'2018-12-16 17:55:25','2018-12-16 17:55:25'),(99,'Severa (50-70%) + En ángulo','<p>Deskripzio desbesdin bat batura honentzako</p>',10,1,'2018-12-16 17:55:44','2018-12-16 17:55:44'),(100,'Extracción','<p>Mecanismo que posibilita la extracción de la pieza de los utillajes.<br/></p>',11,1,'2018-12-16 17:59:05','2018-12-16 17:59:05'),(101,'Introducción','<p>Mecanismo que guia la introduccón de la pieza hasta su posición de conformado.<br/></p>',11,1,'2018-12-16 17:59:21','2018-12-16 17:59:21'),(102,'Sujeción','<p>Conjunto de elementos que sujetan la pieza al salir, meter y mover la pieza entre estaciones.<br/></p>',11,1,'2018-12-16 17:59:36','2018-12-16 17:59:36'),(103,'Matriz abierta','<p>Tipo de recalcado usando matrices segmentadas con geometrias con contrasalidas.<br/></p>',12,1,'2018-12-16 18:00:47','2018-12-16 18:00:47'),(104,'Abierto','<p>Aumentar la sección de una parte del material sin sujetar el material dentro de los utillajes. Límite de recalcado libre r=2<br/></p>',12,1,'2018-12-16 18:01:28','2018-12-16 18:01:28'),(105,'Cerrado','<p>Aumentar la seccion de una parte del material sujetando el material dentro de los utillajes. Límite de recalcado libre r=2<br/></p>',12,1,'2018-12-16 18:01:43','2018-12-16 18:01:43'),(108,'Grandes deformaciones',NULL,8,1,'2018-12-16 18:03:41','2018-12-16 18:03:41'),(109,'Escuadrado','<p>gddafsg</p><p>s</p><p>s</p>',9,1,'2018-12-16 18:04:02','2018-12-16 18:04:02'),(111,'Punzonado',NULL,9,1,'2018-12-16 18:04:36','2018-12-16 18:04:36'),(117,'De paso',NULL,11,1,'2018-12-16 19:10:05','2018-12-16 19:10:05'),(120,'Desde parte fija',NULL,14,1,'2018-12-16 19:13:13','2018-12-16 19:13:13'),(122,'Desde parte móvil',NULL,14,1,'2018-12-16 19:13:54','2018-12-16 19:13:54'),(129,'Standard (30-50%)',NULL,10,15,'2018-12-17 07:09:55','2018-12-17 07:09:55'),(131,'Severa (50-70%) + En ángulo',NULL,10,1,'2018-12-17 15:16:13','2018-12-17 15:16:13'),(132,'Estandar',NULL,11,1,'2018-12-17 15:36:07','2018-12-17 15:36:07'),(157,'Cerrada','<p>Extrusión inversa con todo el material contenido</p>',16,15,'2018-12-26 15:51:31','2018-12-26 15:51:31'),(158,'Parcialmente cerrada','<p>Con herramienta flotante</p>',16,15,'2018-12-26 15:52:07','2018-12-26 15:52:07'),(159,'Abierta','<p>El material no está radialmente contenido. </p>',16,15,'2018-12-26 15:52:55','2018-12-26 15:52:55'),(160,'Recalcado de preforma',NULL,12,15,'2018-12-26 15:57:00','2018-12-26 15:57:00'),(161,'Recorte','<p>Eliminación del sobrante de material<br/></p>',17,15,'2018-12-26 16:00:24','2018-12-26 16:00:24'),(162,'Parcial','<p>Operación previa al recortado total donde se recorta material sin hacerlo pasante</p>',17,15,'2018-12-26 16:01:44','2018-12-26 16:01:44'),(163,'Piercing','<p>Eliminación de pepita</p>',17,15,'2018-12-26 16:10:21','2018-12-26 16:10:21'),(164,'Something',NULL,9,1,'2019-03-02 19:29:22','2019-03-02 19:29:22'),(166,'Standard + Grandes deformaciones',NULL,8,1,'2019-03-03 12:17:59','2019-03-03 12:17:59'),(167,'Nanana',NULL,19,1,'2019-03-03 17:46:47','2019-03-03 17:46:47'),(168,'Nwe One',NULL,19,1,'2019-03-03 17:52:08','2019-03-03 17:52:08'),(169,'Abierto + Cerrado',NULL,12,1,'2019-03-05 13:19:40','2019-03-05 13:19:40'),(170,'Nonono',NULL,19,1,'2019-03-05 15:30:10','2019-03-05 15:30:10'),(171,'Nonono + Nwe One',NULL,19,1,'2019-03-05 15:47:10','2019-03-05 15:47:10'),(172,'Recorte + Parcial',NULL,17,1,'2019-03-05 15:50:59','2019-03-05 15:50:59'),(173,'Recorte + Parcial',NULL,17,1,'2019-03-06 17:16:22','2019-03-06 17:16:22'),(174,'pmm','<p>lñl</p>',16,1,'2019-03-06 18:23:54','2019-03-06 18:23:54');
/*!40000 ALTER TABLE `process_op` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op_rel`
--

DROP TABLE IF EXISTS `process_op_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op_rel` (
  `parent_id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL,
  UNIQUE KEY `rel` (`parent_id`,`child_id`),
  KEY `child_id` (`child_id`),
  CONSTRAINT `process_op_rel_ibfk_2` FOREIGN KEY (`child_id`) REFERENCES `process_op` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `process_op_rel_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `process_op` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op_rel`
--

LOCK TABLES `process_op_rel` WRITE;
/*!40000 ALTER TABLE `process_op_rel` DISABLE KEYS */;
INSERT INTO `process_op_rel` VALUES (97,99),(98,99),(97,131),(98,131),(95,166),(108,166),(95,167),(166,167),(104,169),(105,169),(168,171),(170,171),(161,172),(162,172),(161,173),(162,173);
/*!40000 ALTER TABLE `process_op_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op_stg_rel`
--

DROP TABLE IF EXISTS `process_op_stg_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op_stg_rel` (
  `op_id` int(11) NOT NULL,
  `stg_id` int(11) NOT NULL,
  UNIQUE KEY `op_stg_rel` (`op_id`,`stg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op_stg_rel`
--

LOCK TABLES `process_op_stg_rel` WRITE;
/*!40000 ALTER TABLE `process_op_stg_rel` DISABLE KEYS */;
INSERT INTO `process_op_stg_rel` VALUES (29,167),(34,167),(40,157),(47,167),(47,168),(47,170);
/*!40000 ALTER TABLE `process_op_stg_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_op_type`
--

DROP TABLE IF EXISTS `process_op_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_op_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(255) NOT NULL,
  `descr` text,
  `uid` int(11) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_op_type`
--

LOCK TABLES `process_op_type` WRITE;
/*!40000 ALTER TABLE `process_op_type` DISABLE KEYS */;
INSERT INTO `process_op_type` VALUES (8,'Corte','<p>Corte transversal del alambre ya enderezado a la longitud deseada, es importante el acabado de la zona deformada para evitar problemas posteriores.<br/></p>',1,'2018-12-16 17:50:37','2018-12-16 17:50:37'),(9,'Preparación',NULL,1,'2018-12-16 17:53:47','2018-12-16 17:53:47'),(10,'Extrusión Hacia Delante','<p>Forward extrusion</p>',1,'2018-12-16 17:54:31','2018-12-16 17:54:31'),(11,'Transporte',NULL,1,'2018-12-16 17:58:42','2018-12-16 17:58:42'),(12,'Recalcado',NULL,1,'2018-12-16 17:59:56','2018-12-16 17:59:56'),(14,'Empuje',NULL,1,'2018-12-16 19:13:01','2018-12-16 19:13:01'),(16,'Extrusión Inversa','<p>Backward Extrusion, Taladrado, Punzonado<br/></p>',15,'2018-12-26 15:24:16','2018-12-26 15:24:16'),(17,'Recorte','<p>Arrastre  de material /Eliminación de material sobrante.</p>',15,'2018-12-26 15:59:25','2018-12-26 15:59:25'),(19,'Frogak',NULL,1,'2019-01-24 08:29:27','2019-01-24 08:29:27');
/*!40000 ALTER TABLE `process_op_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_stage`
--

DROP TABLE IF EXISTS `process_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_stage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` text,
  `v_id` int(11) NOT NULL COMMENT 'version',
  `uid` int(11) NOT NULL COMMENT 'owner',
  `ord` int(2) NOT NULL DEFAULT '0' COMMENT 'order',
  `cmm_c` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `version` (`v_id`),
  KEY `user` (`uid`),
  CONSTRAINT `process_stage_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `user` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `version` FOREIGN KEY (`v_id`) REFERENCES `process_version` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_stage`
--

LOCK TABLES `process_stage` WRITE;
/*!40000 ALTER TABLE `process_stage` DISABLE KEYS */;
INSERT INTO `process_stage` VALUES (29,'<p>Pellentesque viverra ut nulla non tincidunt. Proin pharetra lectus a orci cursus rhoncus. </p><ul><li>Aliquam mollis massa eu tincidunt pretium. </li></ul><ul><li>Aenean viverra lobortis ipsum. </li></ul><p>Duis et eros a ante placerat mattis.<b> Aliquam eros nisi</b>, sagittis vel faucibus vel, finibus ac lacus.</p>',8,1,1,1,'2019-03-06 16:03:44','2019-03-06 16:03:44'),(34,'<p>Pellentesque viverra ut nulla non tincidunt. Proin pharetra lectus a orci cursus rhoncus. </p><ul><li>Aliquam mollis massa eu tincidunt pretium. </li></ul><ul><li>Aenean viverra lobortis ipsum. </li></ul><p>Duis et eros a ante placerat mattis.<b> Aliquam eros nisi</b>, sagittis vel faucibus vel, finibus ac lacus.</p>',11,1,0,1,'2019-03-06 17:24:33','2019-03-06 17:24:33'),(40,NULL,8,1,0,0,'2019-03-06 17:58:21','2019-03-06 17:58:21'),(47,'<p>Pellentesque viverra ut nulla non tincidunt. Proin pharetra lectus a orci cursus rhoncus. </p><ul><li>Aliquam mollis massa eu tincidunt pretium. </li></ul><ul><li>Aenean viverra lobortis ipsum. </li></ul><p>Duis et eros a ante placerat mattis.<b> Aliquam eros nisi</b>, sagittis vel faucibus vel, finibus ac lacus.</p>',18,1,0,1,'2019-03-06 18:54:50','2019-03-06 18:54:50');
/*!40000 ALTER TABLE `process_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_version`
--

DROP TABLE IF EXISTS `process_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `prc_id` int(11) NOT NULL,
  `mtl_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `descr` text,
  `cmm_c` int(4) NOT NULL DEFAULT '0',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `process` (`prc_id`),
  CONSTRAINT `process` FOREIGN KEY (`prc_id`) REFERENCES `process` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_version`
--

LOCK TABLES `process_version` WRITE;
/*!40000 ALTER TABLE `process_version` DISABLE KEYS */;
INSERT INTO `process_version` VALUES (8,'V_2',1,1,1,'<p>....</p>',0,'2019-03-06 16:03:44','2019-03-06 16:03:44'),(11,'V_2',1,1,1,'<p>....</p>',9,'2019-03-06 17:24:33','2019-03-06 17:24:33'),(18,'Clone of V_2',1,1,1,'<p>....</p>',0,'2019-03-06 18:54:50','2019-03-06 18:54:50');
/*!40000 ALTER TABLE `process_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `state` smallint(6) DEFAULT NULL,
  `roles` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UNIQ_8D93D649F85E0677` (`username`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'Pamintxa','iturri.jon@gmail.com',NULL,'$2y$14$OHIf0Zq2F1kfLdQAiRzOm.onMwULghwUpizRJvqokJBHUPD18tmUC',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-27 17:40:09','0000-00-00 00:00:00'),(13,'JJOxemaiB','jjoxemaib@example.com',NULL,'$2y$14$WzYaePOiSukHEuAtfkasle6cPP4EGIELTRjA4KwaVAGWH7UUGTLp.',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-30 07:28:30','2018-11-30 07:28:30'),(14,'AITOR','diaz@imaltuna.com',NULL,'$2y$14$5XB/qM.PPOPFEtB/Cgz9uu04prFbvurOG.dSTjCEkyrzcxygz4Nmm',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-30 11:10:29','2018-11-30 11:10:29'),(15,'Unai Ziarsolo','unai@maltuna.eus',NULL,'$2y$14$UDAQji1qKcGa9xT4rqglYu5jUauFftnWvmdh.g40r1Sop4WK/YXZi',NULL,'a:1:{i:0;s:4:\"user\";}','2018-11-30 11:30:09','2018-11-30 11:30:09'),(16,'UnaiEcenarro','ucornes@ecenarro.com',NULL,'$2y$14$ABytkkPetNyLbgydbQ5/TOO5o7VJa9C83BX8m9ad/X9ZYB9r/7B7S',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:05:48','2018-12-17 16:05:48'),(17,'MariaAzpeitia','mazpeitia@ecenarro.com',NULL,'$2y$14$7n/2a876TJjzjvIu5qrhz.Hlc8/O0WfjWomh2dE3YRuphWzlZTz3C',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:07:07','2018-12-17 16:07:07'),(18,'Jon Agirre','jagirre@ecenarro.com',NULL,'$2y$14$MjGrviJbGArW91k6VxGzAepQhV.p4obk9SQVSc7OEBBjR4SyZ1Z3a',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:07:35','2018-12-17 16:07:35'),(19,'Patxi Molina','pmolina@ecenarro.com',NULL,'$2y$14$EcWGPnORV8/ZvPzM0FtjGeVLrQS0mLtF/Gqpl1DeDLmJKrqUTwMAq',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:08:03','2018-12-17 16:08:03'),(20,'Jon Arriaran','jarriaran@ecenarro.com',NULL,'$2y$14$jMRCkszHBdY.Ozz6g971pOy/jHOnwX6LmJs8tjPk8HhHlqyrn41ki',NULL,'a:1:{i:0;s:4:\"user\";}','2018-12-17 16:11:58','2018-12-17 16:11:58');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-08 11:20:07
